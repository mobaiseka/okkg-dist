@echo off
chcp 65001 >nul
cd /d %~dp0
set CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe
if not exist "%CSC%" set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" (
  echo [FAIL] 未找到系统 csc.exe，无法编译
  pause
  exit /b 1
)
echo 正在编译 ok-gui.exe ...
"%CSC%" /nologo /optimize+ /target:winexe /out:ok-gui.exe /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:Microsoft.CSharp.dll OkkGui.cs LogoPaths.cs
if %errorlevel%==0 (
  echo [OK] 编译成功！已生成 ok-gui.exe
  echo 请把它替换到主程序目录使用（删除目录里旧的 ok-gui.cfg）
) else (
  echo [FAIL] 编译失败，请把上面的错误信息截图发给我
)
pause
