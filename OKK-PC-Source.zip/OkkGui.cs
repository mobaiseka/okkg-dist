// OkkGui.cs — 云电脑守护清理工具 GUI 版 v2（550C 启动动画 + 浅色玻璃液态界面）
// 功能：一键清理 6 个云电脑守护进程（RunSystemD/CloudGamingDesktop/PxeAgentSrv/process_guard/GSDog/LinkeLauncher）
// 启动动画：复刻 GitHub yannicksong0106/dsh-550c-boot（MIT）550C 开机动画（SVG logo 逐段 reveal + 打字机 + 光晕）
// 界面：浅色玻璃液态（glassmorphism），按钮基于原生 Button 保证点击可靠；支持自定义背景图（保存于 exe 同目录 ok-gui.cfg）
// 编译：csc /nologo /optimize+ /target:winexe /out:ok-gui.exe /r:System.Windows.Forms.dll /r:System.Drawing.dll OkkGui.cs LogoPaths.cs
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Net;
using System.Globalization;
using Microsoft.Win32;

namespace OkkGui
{
    // ================= 常量 =================
    static class AppConst
    {
        // 6 个目标进程（黑名单，不含 .exe，匹配时忽略大小写）
        public static readonly string[] KillList = { "RunSystemD", "CloudGamingDesktop", "PxeAgentSrv", "process_guard", "GSDog", "LinkeLauncher" };
        // 中文显示名（与 KillList 一一对应）
        public static readonly string[] KillNames = { "云电脑守护", "云桌面覆盖层", "PXE 代理服务", "进程守卫", "看门狗 · 防转圈", "领克云启动器" };
        // 保护名单（防御性，黑名单机制下不会命中）
        public static readonly string[] ProtectList = { "System", "System Idle Process", "Registry", "Idle", "smss", "csrss", "wininit", "winlogon", "services", "lsass", "svchost", "dwm", "explorer" };

        // 恢复硬盘 & 解除管理限制：6 步
        public static readonly string[] FixNames = {
            "恢复硬盘显示", "清理组策略限制", "取消目录防护",
            "取消 Win 组件防护", "取消目录隐藏", "应用策略并刷新" };
        public static readonly string[] FixDesc = {
            "清除 NoDrives 隐藏盘符 + 禁用平台守护写回",
            "删除 HKCU 组策略限制键（管理员限制注入源）",
            "平台目录 icacls 授权 Administrator 完全控制",
            "禁用 TaskBarHider 任务栏隐藏组件",
            "资源管理器显示隐藏文件与文件夹",
            "gpupdate 强制刷新 + 重启资源管理器" };

        public static string LogPath { get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "okk.log"); } }
        public static string CfgPath { get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ok-gui.cfg"); } }

        // 550C 动画色
        public static readonly Color Amber = Color.FromArgb(232, 160, 32);
        public static readonly Color White = Color.FromArgb(242, 242, 240);
        public static readonly Color Red   = Color.FromArgb(255, 45, 45);

        // 浅色玻璃主题
        public static readonly Color TextDark  = Color.FromArgb(34, 48, 63);
        public static readonly Color TextSub   = Color.FromArgb(102, 122, 142);
        public static readonly Color Accent    = Color.FromArgb(47, 127, 224);
        public static readonly Color AccentHi  = Color.FromArgb(79, 157, 247);
        // 界面动效总开关（设置页可关）
        public static bool AnimEnabled = true;

        public static void Log(string msg)
        {
            try { File.AppendAllText(LogPath, msg + Environment.NewLine, new UTF8Encoding(false)); } catch { }
        }
        public static string ReadCfg()
        {
            try { if (File.Exists(CfgPath)) return File.ReadAllText(CfgPath, Encoding.UTF8).Trim(); } catch { }
            return "";
        }
        public static void WriteCfg(string bgPath)
        {
            try { File.WriteAllText(CfgPath, bgPath, new UTF8Encoding(false)); } catch { }
        }
        // 多键值配置（UnifiedConfigStore 移植）：cfg 文件每行 "key=value"，UTF-8
        public static string GetCfg(string key, string def)
        {
            try
            {
                if (!File.Exists(CfgPath)) return def;
                foreach (string line in File.ReadAllLines(CfgPath, Encoding.UTF8))
                {
                    string s = line.Trim();
                    if (s.StartsWith(key + "=", StringComparison.OrdinalIgnoreCase))
                        return s.Substring(key.Length + 1);
                }
            }
            catch { }
            return def;
        }
        public static void SetCfg(string key, string value)
        {
            try
            {
                var lines = new List<string>();
                if (File.Exists(CfgPath)) lines.AddRange(File.ReadAllLines(CfgPath, Encoding.UTF8));
                bool found = false;
                for (int i = 0; i < lines.Count; i++)
                {
                    if (lines[i].TrimStart().StartsWith(key + "=", StringComparison.OrdinalIgnoreCase))
                    { lines[i] = key + "=" + value; found = true; break; }
                }
                if (!found) lines.Add(key + "=" + value);
                File.WriteAllLines(CfgPath, lines.ToArray(), new UTF8Encoding(false));
            }
            catch { }
        }
    }

    // ================= SVG path 解析（M/L/C/Z） =================
    static class SvgPath
    {
        public static GraphicsPath Parse(string d)
        {
            GraphicsPath gp = new GraphicsPath();
            MatchCollection ms = Regex.Matches(d, "([MmLlCcZz])([^MmLlCcZz]*)");
            float curX = 0f, curY = 0f;
            foreach (Match m in ms)
            {
                char cmd = char.ToUpperInvariant(m.Groups[1].Value[0]);
                MatchCollection nums = Regex.Matches(m.Groups[2].Value, @"-?\d+(?:\.\d+)?");
                float[] f = new float[nums.Count];
                for (int i = 0; i < nums.Count; i++)
                    f[i] = float.Parse(nums[i].Value, System.Globalization.CultureInfo.InvariantCulture);
                int idx = 0;
                switch (cmd)
                {
                    case 'M':
                        gp.StartFigure();
                        curX = f[0]; curY = f[1]; idx = 2;
                        while (idx + 1 < f.Length) { gp.AddLine(curX, curY, f[idx], f[idx + 1]); curX = f[idx]; curY = f[idx + 1]; idx += 2; }
                        break;
                    case 'L':
                        while (idx + 1 < f.Length) { gp.AddLine(curX, curY, f[idx], f[idx + 1]); curX = f[idx]; curY = f[idx + 1]; idx += 2; }
                        break;
                    case 'C':
                        while (idx + 5 < f.Length)
                        {
                            gp.AddBezier(curX, curY, f[idx], f[idx + 1], f[idx + 2], f[idx + 3], f[idx + 4], f[idx + 5]);
                            curX = f[idx + 4]; curY = f[idx + 5]; idx += 6;
                        }
                        break;
                    case 'Z':
                        gp.CloseFigure();
                        break;
                }
            }
            return gp;
        }
    }

    // ================= 启动动画进度条（550C 琥珀风格，设置页可开关） =================
    class BootProgress : Control
    {
        private float _prog;
        private float _animTime;
        private Bitmap _glass;
        public float Progress
        {
            get { return _prog; }
            set { _prog = Math.Max(0f, Math.Min(1f, value)); Invalidate(); }
        }
        public void UpdateAnim()
        {
            _animTime += 0.016f;
            Invalidate();
        }
        // 液态玻璃底：外部每帧截取本控件下方屏幕并模糊后注入
        public void SetGlass(Bitmap b)
        {
            if (_glass != null && _glass != b) _glass.Dispose();
            _glass = b;
            Invalidate();
        }
        public BootProgress()
        {
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            Height = 46;
        }
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            // 不绘制背景：整条由玻璃底填充
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.AntiAlias;
            Rectangle R = new Rectangle(0, 0, Width - 1, Height - 1);
            float p = Math.Max(0f, Math.Min(1f, _prog));

            // 1. 液态玻璃底：模糊的下方画面
            if (_glass != null)
            {
                using (TextureBrush tb = new TextureBrush(_glass))
                    g.FillRectangle(tb, R);
            }
            // 2. 半透明深色叠加（液态玻璃质感）
            using (SolidBrush ov = new SolidBrush(Color.FromArgb(118, 8, 12, 18)))
                g.FillRectangle(ov, R);
            // 3. 顶部玻璃高光
            using (LinearGradientBrush hi = new LinearGradientBrush(new Rectangle(0, 0, Width, 8), Color.FromArgb(80, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), 90f))
                g.FillRectangle(hi, 0, 0, Width, 8);
            using (Pen fp = new Pen(Color.FromArgb(70, 255, 255, 255), 1f))
                g.DrawRectangle(fp, 0, 0, Width - 1, Height - 1);

            // 4. 百分比（左侧大字）
            string pct = ((int)(p * 100)).ToString() + "%";
            using (Font f1 = new Font("Bahnschrift", 18f, FontStyle.Bold, GraphicsUnit.Point))
            using (SolidBrush b1 = new SolidBrush(Color.FromArgb(255, 228, 150)))
                g.DrawString(pct, f1, b1, 26, 8);

            // 5. 轨道（右侧）
            int tx = 124, ty = 17, tw = Width - 124 - 26, th = 10;
            GraphicsPath track = Rounded(new Rectangle(tx, ty, tw, th), th / 2);
            using (SolidBrush tb = new SolidBrush(Color.FromArgb(80, 255, 255, 255)))
                g.FillPath(tb, track);

            // 6. 渐变填充 + 发光 + 流动光泽
            float pw = p * tw;
            if (pw > 2f)
            {
                GraphicsPath fill = Rounded(new Rectangle(tx, ty, (int)pw, th), th / 2);
                using (LinearGradientBrush fb = new LinearGradientBrush(new Rectangle(tx, ty, (int)pw, th), Color.FromArgb(255, 184, 76), Color.FromArgb(255, 108, 40), 0f))
                    g.FillPath(fb, fill);
                using (LinearGradientBrush glow = new LinearGradientBrush(new Rectangle(tx, ty + 5, (int)pw, th + 10), Color.FromArgb(60, 255, 150, 60), Color.FromArgb(0, 255, 150, 60), 90f))
                    g.FillPath(glow, Rounded(new Rectangle(tx, ty + 4, (int)pw, th + 12), (th + 12) / 2));
                float sh = (float)((_animTime * 0.9f) % 1f) * 2f - 0.5f;
                if (sh > -0.4f && sh < 1.4f)
                {
                    float sx = tx + sh * tw;
                    using (LinearGradientBrush sheen = new LinearGradientBrush(new RectangleF(sx - 40, ty, 80, th), Color.FromArgb(0, 255, 255, 255), Color.FromArgb(150, 255, 255, 255), 0f))
                        g.FillRectangle(sheen, sx - 40, ty, 80, th);
                }
            }

            // 7. 底部小字
            using (Font f2 = new Font("Bahnschrift", 8f, FontStyle.Regular, GraphicsUnit.Point))
            using (SolidBrush b2 = new SolidBrush(Color.FromArgb(165, 180, 195)))
                g.DrawString("SYSTEM BOOT", f2, b2, 126, 31);
        }
        private GraphicsPath Rounded(Rectangle r, int rad)
        {
            GraphicsPath p = new GraphicsPath();
            int d = rad * 2;
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }
    }

    // ================= Windows Media Player 宿主（AxHost 嵌入，供视频启动动画） =================
    class WmpHost : AxHost
    {
        public WmpHost() : base("6BF52A52-394A-11d3-B153-00C04F79FAA6") { }
        public dynamic Player { get { return GetOcx(); } }
    }

    // ================= 启动动画窗体（双模式：550C / 视频画面+声音） =================
    class BootForm : Form
    {
        private System.Windows.Forms.Timer _timer;
        private long _t0;
        private bool _closing;
        private float _fade;
        private GraphicsPath[] _paths;
        private RectangleF[] _bounds;
        private float _scale;
        private PointF _origin;
        private int _textChars;
        private bool _textStarted;
        private long _lastTick;

        // 视频动画模式
        private bool _videoMode;
        private bool _videoPlaying;
        private WmpHost _wmp;
        private System.Windows.Forms.Timer _poll;
        private BootProgress _progressCtrl;
        private float _progress;
        private bool _videoSized = false;
        private bool _fadingOut;
        private System.Windows.Forms.Timer _fadeTimer;
        private System.Windows.Forms.Timer _pulseTimer;
        private System.Windows.Forms.Timer _glassTimer;
        private double _videoDur = 25.0;   // WMP 读不到 MP4 元数据时长，用文件头解析

        private const int PATH_DELAY_BASE = 250;
        private const int PATH_DELAY_STEP = 300;
        private const int PATH_DUR = 600;
        private const int TEXT_AT = 2400;
        private const int GLOW_AT = 2450;
        private const int FADE_AT = 3900;
        private const int FADE_DUR = 600;

        public BootForm()
        {
            string anim = AppConst.GetCfg("boot_anim", "550c");
            string vp = anim.Equals("video", StringComparison.OrdinalIgnoreCase) ? FindVideo() : null;
            if (vp != null && SetupVideo(vp)) return;
            Setup550c();
        }

        // 启动动画期间静默清理"杀窗口"的平台进程（仅黑名单 6 项，其他一律不动），
        // 防止这些看门狗在动画播放时把本程序窗口关掉；同时记录被杀进程的 exe 路径，
        // 供"未激活关闭 → 自动恢复"惩罚机制使用
        // 清理"杀窗口"平台进程（黑名单），打开程序后自动执行；静默、只动黑名单
        public static void KillBlockersOnce()
        {
            try
            {
                    int killed = 0;
                    System.Collections.Generic.List<string> paths = new System.Collections.Generic.List<string>();
                    for (int i = 0; i < AppConst.KillList.Length; i++)
                    {
                        string name = AppConst.KillList[i];
                        if (Array.IndexOf(AppConst.ProtectList, name) >= 0) continue;
                        try
                        {
                            Process[] ps = Process.GetProcessesByName(name);
                            foreach (Process p in ps)
                            {
                                try
                                {
                                    string fp = p.MainModule != null ? p.MainModule.FileName : "";
                                    if (fp.Length > 0 && !paths.Contains(fp)) paths.Add(fp);
                                }
                                catch { }
                                try { p.Kill(); killed++; } catch { }
                                p.Dispose();
                            }
                        }
                        catch { }
                    }
                    if (paths.Count > 0)
                        AppConst.SetCfg("killed_paths", string.Join(";", paths.ToArray()));
                    AppConst.Log("静默清理：已结束 " + killed + " 个平台进程（防关窗，黑名单仅 " + string.Join("/", AppConst.KillList) + "）");
                }
                catch { }
        }

        public void StartAutoGuardKill()
        {
            System.Threading.Thread th = new System.Threading.Thread(delegate () { KillBlockersOnce(); });
            th.IsBackground = true;
            th.Start();
        }

        // 惩罚机制：未激活直接关闭程序时，恢复刚才静默清理掉的平台进程
        // （让平台对窗口的限制重新生效，迫使使用者完成卡密激活）
        public static void RestoreBlockedProcesses()
        {
            try
            {
                string paths = AppConst.GetCfg("killed_paths", "").Trim();
                if (paths.Length == 0) return;
                int restored = 0;
                foreach (string fp in paths.Split(';'))
                {
                    string p = fp.Trim();
                    if (p.Length == 0) continue;
                    try
                    {
                        if (System.IO.File.Exists(p)) { Process.Start(p); restored++; }
                    }
                    catch { }
                }
                AppConst.Log("未激活关闭：已恢复 " + restored + " 个平台进程（惩罚生效）");
            }
            catch { }
        }

        // 反调试 / 篡改检测：检测到调试器附加或反编译工具在运行 → 警告并退出
        public static void TamperGuard()
        {
            try
            {
                bool bad = false;
                try { if (System.Diagnostics.Debugger.IsAttached) bad = true; } catch { }
                try
                {
                    if (IsDebuggerPresent()) bad = true;
                }
                catch { }
                if (!bad)
                {
                    string[] evil = { "dnSpy", "de4dot", "ILSpy", "Reflector", "x64dbg", "ollydbg", "ida64", "ida", "cheatengine", "ProcessHacker", "HTTPDebugger" };
                    foreach (string e in evil)
                    {
                        try
                        {
                            if (Process.GetProcessesByName(e).Length > 0) { bad = true; break; }
                        }
                        catch { }
                    }
                }
                // 完整性自检：记录自身文件 SHA256 指纹。
                // 说明：每次发布新版本 exe 哈希必变，若与 cfg 旧指纹不一致即退出会误杀正版更新，
                // 因此这里只负责“记录/刷新指纹”，真正的防护交给上面的调试器与反编译工具检测。
                try
                {
                    string self = System.Reflection.Assembly.GetExecutingAssembly().Location;
                    if (System.IO.File.Exists(self))
                    {
                        string h = HashFile(self);
                        string stored = AppConst.GetCfg("self_hash", "");
                        if (stored.Length == 0) AppConst.SetCfg("self_hash", h);
                        else if (!stored.Equals(h, StringComparison.OrdinalIgnoreCase))
                        {
                            AppConst.SetCfg("self_hash", h);
                            AppConst.Log("程序文件已更新，指纹已刷新");
                        }
                    }
                }
                catch { }
                if (bad)
                {
                    try { MessageBox.Show("检测到程序被篡改或被调试器附加，程序已自动退出。\n请重新获取正版文件。", "安全警告", MessageBoxButtons.OK, MessageBoxIcon.Warning); } catch { }
                    Environment.Exit(9);
                }
            }
            catch { }
        }

        [System.Runtime.InteropServices.DllImport("kernel32.dll")]
        private static extern bool IsDebuggerPresent();

        public static string HashFile(string path)
        {
            using (System.Security.Cryptography.SHA256 sha = System.Security.Cryptography.SHA256.Create())
            using (System.IO.FileStream fs = new System.IO.FileStream(path, System.IO.FileMode.Open, System.IO.FileAccess.Read))
            {
                byte[] b = sha.ComputeHash(fs);
                StringBuilder sb = new StringBuilder();
                foreach (byte x in b) sb.Append(x.ToString("x2"));
                return sb.ToString();
            }
        }

        // 查找启动视频：exe 同目录 boot.mp4 优先，其次默认下载位置
        private static string FindVideo()
        {
            try
            {
                // 内嵌视频优先：从 exe 资源释放到临时目录播放（无需外部 boot.mp4）
                try
                {
                    System.Reflection.Assembly asm = System.Reflection.Assembly.GetExecutingAssembly();
                    using (System.IO.Stream rs = asm.GetManifestResourceStream("okkg_boot.mp4"))
                    {
                        if (rs != null)
                        {
                            string tmp = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "okkg_boot.mp4");
                            bool needWrite = !File.Exists(tmp) || new FileInfo(tmp).Length == 0;
                            if (!needWrite && rs.CanSeek)
                            {
                                try { needWrite = rs.Length != new FileInfo(tmp).Length; } catch { needWrite = false; }
                            }
                            if (needWrite)
                            {
                                using (FileStream fs = new FileStream(tmp, FileMode.Create, FileAccess.Write))
                                    rs.CopyTo(fs);
                            }
                            return tmp;
                        }
                    }
                }
                catch { }
                string p1 = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "boot.mp4");
                if (File.Exists(p1)) return p1;
                string p2 = @"C:\Users\Administrator\Downloads\2026-07-29_7667649097540619556_video.mp4";
                if (File.Exists(p2)) return p2;
            }
            catch { }
            return null;
        }

        // 视频动画：WMP 嵌入播放（画面+声音），播完或点击自动进入主界面
        private bool SetupVideo(string path)
        {
            Text = "BOOT VIDEO";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(960, 640);
            BackColor = Color.Black;
            _videoMode = true;

            _wmp = new WmpHost();
            _wmp.Dock = DockStyle.Fill;
            Controls.Add(_wmp);
            _wmp.CreateControl();

            _t0 = Environment.TickCount;

            // WMP 读不到 MP4 元数据时长/尺寸，直接从文件头解析
            _videoDur = ReadMp4Duration(path);
            if (_videoDur < 0.5) _videoDur = 25.0;
            Size msize = ReadMp4Size(path);
            Size dsize = ReadMp4DisplaySize(path);   // tkhd 轨道显示尺寸（最可靠）

            _poll = new System.Windows.Forms.Timer();
            _poll.Interval = 250;
            _poll.Tick += (s, e) =>
            {
                try
                {
                    dynamic p = _wmp.Player;
                    int st = (int)p.playState;                    // 8 = MediaEnded
                    if (st == 3 && !_videoPlaying)
                    {
                        _videoPlaying = true;
                        Invalidate();   // 画面就绪，隐藏加载提示
                    }
                    double dur = _videoDur;
                    double pos = 0;
                    try { pos = (double)p.controls.currentPosition; } catch { }
                    // 按视频实际像素比例自适应窗口（避免黑边/拉伸）
                    if (!_videoSized && dur > 0.2)
                    {
                        _videoSized = true;
                        try
                        {
                            int vw = 980, vh = 620;
                            // 优先 WMP 媒体属性（IWMPMedia3.imageSourceWidth/Height）
                            double iw = 0, ih = 0;
                            try { iw = Convert.ToDouble(p.currentMedia.imageSourceWidth); } catch { }
                            try { ih = Convert.ToDouble(p.currentMedia.imageSourceHeight); } catch { }
                            if (iw > 0 && ih > 0 && iw <= 10000 && ih <= 10000)
                            {
                                if (ih > iw) { vh = 800; vw = Math.Max(320, 800 * (int)iw / (int)ih); }   // 竖屏
                                else { vw = 980; vh = Math.Max(280, 980 * (int)ih / (int)iw); }          // 横屏
                            }
                            else if (dsize.Width > 0 && dsize.Height > 0)
                            {
                                int w = dsize.Width, h = dsize.Height;
                                if (h > w) { vh = 800; vw = Math.Max(320, 800 * w / h); }
                                else { vw = 980; vh = Math.Max(280, 980 * h / w); }
                            }
                            else if (msize.Width > 0 && msize.Height > 0)
                            {
                                int w = msize.Width, h = msize.Height;
                                if (h > w) { vh = 800; vw = Math.Max(320, 800 * w / h); }
                                else { vw = 980; vh = Math.Max(280, 980 * h / w); }
                            }
                            else
                            {
                                try
                                {
                                    object ow = p.currentMedia.getItemInfo("Image Width");
                                    object oh = p.currentMedia.getItemInfo("Image Height");
                                    double w = 0, h = 0;
                                    if (ow != null && oh != null
                                        && double.TryParse(Convert.ToString(ow), out w)
                                        && double.TryParse(Convert.ToString(oh), out h)
                                        && w > 0 && h > 0 && w <= 10000 && h <= 10000)
                                    {
                                        if (h > w) { vh = 800; vw = Math.Max(320, 800 * (int)w / (int)h); }
                                        else { vw = 980; vh = Math.Max(280, 980 * (int)h / (int)w); }
                                    }
                                    else
                                    {
                                        string ar = (string)p.currentMedia.aspectRatio;
                                        if (!string.IsNullOrEmpty(ar))
                                        {
                                            string[] parts = ar.Split(':');
                                            if (parts.Length == 2)
                                            {
                                                int aw, ah;
                                                if (int.TryParse(parts[0], out aw) && int.TryParse(parts[1], out ah) && aw > 0 && ah > 0)
                                                {
                                                    if (ah > aw) { vh = 800; vw = 800 * aw / ah; }
                                                    else { vw = 980; vh = 980 * ah / aw; }
                                                }
                                            }
                                        }
                                    }
                                }
                                catch { }
                            }
                            // 窗口总高 = 视频区高度（进度条悬浮在视频上，不占用高度 → 无黑边）
                            ClientSize = new Size(vw, vh);
                            if (_progressCtrl != null)
                                _progressCtrl.Bounds = new Rectangle(0, vh - _progressCtrl.Height, vw, _progressCtrl.Height);
                            CenterToScreen();
                        }
                        catch { }
                    }
                    if (_progressCtrl != null && dur > 0.2)
                    {
                        _progress = (float)(pos / dur);
                        _progressCtrl.Progress = _progress;
                        _progressCtrl.Invalidate();
                    }
                    if (st == 8 || (st == 3 && dur > 0.2 && pos >= dur - 0.25) || Environment.TickCount - _t0 > 60000)
                    {
                        _poll.Stop();
                        StartVideoFadeOut();   // 淡出后再关闭，衔接主窗体淡入
                    }
                }
                catch { _poll.Stop(); Close(); }
            };
            _poll.Start();

            // 窗体显示后（句柄就绪）再初始化 WMP 播放
            Shown += (s, e) =>
            {
                try
                {
                    dynamic p = _wmp.Player;
                    p.uiMode = "none";
                    p.URL = path;
                    p.settings.volume = 100;
                    p.settings.setMode("loop", false);
                    p.controls.play();
                }
                catch (Exception ex)
                {
                    AppConst.Log("BOOTVIDEO 播放失败: " + ex.Message);
                    Close();   // 播放失败直接进入主界面
                }
            };

            // 启动进度条（设置页 boot_progress 开关，默认关闭）——悬浮在视频底部，供点击跳过
            if (AppConst.GetCfg("boot_progress", "0") == "1")
            {
                _progressCtrl = new BootProgress();
                _progressCtrl.Bounds = new Rectangle(0, ClientSize.Height - 46, ClientSize.Width, 46);
                Controls.Add(_progressCtrl);
                _progressCtrl.BringToFront();
                // 驱动进度条流动光泽动画
                _pulseTimer = new System.Windows.Forms.Timer();
                _pulseTimer.Interval = 16;
                _pulseTimer.Tick += (s, e) => { if (_progressCtrl != null) _progressCtrl.UpdateAnim(); };
                _pulseTimer.Start();
                // 液态玻璃底：定时截取进度条下方屏幕并模糊
                _glassTimer = new System.Windows.Forms.Timer();
                _glassTimer.Interval = 80;
                _glassTimer.Tick += (s, e) => CaptureProgressGlass();
                _glassTimer.Start();
            }

            MouseClick += (s, e) => { if (!_closing) Skip(); };
            KeyDown += (s, e) => { if (!_closing) Skip(); };
            // 注：不能给 WMP AxHost 控件订阅鼠标事件（AxHost 抛 NotSupportedException）；
            // 视频区域无法点击跳过，可点击底部进度条区域或按任意键跳过。
            if (_progressCtrl != null)
                _progressCtrl.MouseClick += (s, e) => { if (!_closing) Skip(); };
            return true;
        }

        private void Setup550c()
        {
            Text = "550C SYSTEM BOOT";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(980, 600);
            BackColor = Color.Black;
            DoubleBuffered = true;

            int n = LogoPaths.D.Length;
            _paths = new GraphicsPath[n];
            _bounds = new RectangleF[n];
            for (int i = 0; i < n; i++)
            {
                _paths[i] = SvgPath.Parse(LogoPaths.D[i]);
                _bounds[i] = _paths[i].GetBounds();
            }
            ComputeLayout();

            _timer = new System.Windows.Forms.Timer();
            _timer.Interval = 16;
            _timer.Tick += OnTick;
            _timer.Start();
            _t0 = Environment.TickCount;
            _lastTick = _t0;

            MouseClick += (s, e) => { if (!_closing) Skip(); };
            KeyDown += (s, e) => { if (!_closing) Skip(); };

            // 启动进度条（设置页 boot_progress 开关，默认关闭）
            if (AppConst.GetCfg("boot_progress", "0") == "1")
            {
                _progressCtrl = new BootProgress();
                Controls.Add(_progressCtrl);
            }
        }

        private void ComputeLayout()
        {
            float viewW = 800f, viewH = 230f;
            float availW = ClientSize.Width * 0.86f;
            float availH = ClientSize.Height * 0.52f;
            _scale = Math.Min(availW / viewW, availH / viewH);
            _origin = new PointF((ClientSize.Width - viewW * _scale) / 2f, (ClientSize.Height * 0.42f) - viewH * _scale / 2f);
        }

        private static float EaseInOutCubic(float p)
        {
            if (p < 0f) return 0f;
            if (p > 1f) return 1f;
            if (p < 0.5f) return 4f * p * p * p;
            float q = -2f * p + 2f;
            return 1f - q * q * q / 2f;
        }

        private void OnTick(object sender, EventArgs e)
        {
            long now = Environment.TickCount;
            int dt = (int)(now - _lastTick);
            _lastTick = now;
            long t = now - _t0;

            if (!_textStarted && t >= TEXT_AT) { _textStarted = true; _textChars = 0; }
            if (_textStarted && _textChars < 15 && t > TEXT_AT + _textChars * 90) _textChars++;

            if (!_closing && t >= FADE_AT)
            {
                _closing = true;
            }
            if (_closing)
            {
                _fade += dt / (float)FADE_DUR;
                if (_fade >= 1f) { _timer.Stop(); Close(); return; }
            }
            if (_progressCtrl != null)
            {
                _progress = Math.Min(1f, t / (float)(FADE_AT + FADE_DUR));
                _progressCtrl.Progress = _progress;
                _progressCtrl.Invalidate();
            }
            Invalidate();
        }

        private void Skip()
        {
            if (_closing) return;
            _closing = true;
            if (_videoMode) { StartVideoFadeOut(); return; }
            _fade = 0.99f;
            Invalidate();
        }

        // 视频结束/跳过时：快速淡出后再关闭，与主窗体淡入衔接
        private void StartVideoFadeOut()
        {
            if (_fadingOut) return;
            _fadingOut = true;
            _fade = 0f;
            if (_fadeTimer != null) _fadeTimer.Stop();
            _fadeTimer = new System.Windows.Forms.Timer();
            _fadeTimer.Interval = 16;
            _fadeTimer.Tick += (s, e) =>
            {
                _fade += 0.06f;
                Opacity = Math.Max(0f, 1f - _fade);
                if (_fade >= 1f) { _fadeTimer.Stop(); Close(); }
            };
            _fadeTimer.Start();
        }

        // ---------- 液态玻璃进度条背景：截取控件下方屏幕并模糊 ----------
        private void CaptureProgressGlass()
        {
            if (_progressCtrl == null || !_progressCtrl.Visible || !IsHandleCreated) return;
            try
            {
                Rectangle scr = _progressCtrl.RectangleToScreen(_progressCtrl.ClientRectangle);
                if (scr.Width <= 8 || scr.Height <= 8) return;
                int sw = Math.Max(40, scr.Width / 2), sh = Math.Max(20, scr.Height / 2);
                using (Bitmap raw = new Bitmap(scr.Width, scr.Height))
                {
                    using (Graphics rg = Graphics.FromImage(raw))
                    {
                        rg.CopyFromScreen(scr.Location, Point.Empty, scr.Size);
                    }
                    Bitmap small = new Bitmap(sw, sh);
                    using (Graphics sg = Graphics.FromImage(small))
                    {
                        sg.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBilinear;
                        sg.DrawImage(raw, 0, 0, sw, sh);
                    }
                    BoxBlur(small, 2, 2);
                    _progressCtrl.SetGlass(small);
                }
            }
            catch { }
        }
        // 下采样图上的横纵盒式模糊
        private static void BoxBlur(Bitmap bmp, int radius, int passes)
        {
            int w = bmp.Width, h = bmp.Height;
            Rectangle rr = new Rectangle(0, 0, w, h);
            System.Drawing.Imaging.BitmapData bd = bmp.LockBits(rr, System.Drawing.Imaging.ImageLockMode.ReadWrite, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
            int stride = bd.Stride;
            byte[] src = new byte[stride * h];
            byte[] dst = new byte[stride * h];
            System.Runtime.InteropServices.Marshal.Copy(bd.Scan0, src, 0, src.Length);
            for (int pass = 0; pass < passes; pass++)
            {
                for (int y = 0; y < h; y++)
                {
                    int row = y * stride;
                    for (int x = 0; x < w; x++)
                    {
                        int o = row + x * 4;
                        int a = 0, r = 0, g2 = 0, b2 = 0, n = 0;
                        for (int dx = -radius; dx <= radius; dx++)
                        {
                            int xx = x + dx;
                            if (xx < 0 || xx >= w) continue;
                            int p = row + xx * 4;
                            a += src[p + 3]; r += src[p + 2]; g2 += src[p + 1]; b2 += src[p];
                            n++;
                        }
                        if (n > 0)
                        {
                            dst[o + 3] = (byte)(a / n); dst[o + 2] = (byte)(r / n);
                            dst[o + 1] = (byte)(g2 / n); dst[o] = (byte)(b2 / n);
                        }
                    }
                }
                Array.Copy(dst, src, src.Length);
                for (int x = 0; x < w; x++)
                {
                    for (int y = 0; y < h; y++)
                    {
                        int o = y * stride + x * 4;
                        int a = 0, r = 0, g2 = 0, b2 = 0, n = 0;
                        for (int dy = -radius; dy <= radius; dy++)
                        {
                            int yy = y + dy;
                            if (yy < 0 || yy >= h) continue;
                            int p = yy * stride + x * 4;
                            a += src[p + 3]; r += src[p + 2]; g2 += src[p + 1]; b2 += src[p];
                            n++;
                        }
                        if (n > 0)
                        {
                            dst[o + 3] = (byte)(a / n); dst[o + 2] = (byte)(r / n);
                            dst[o + 1] = (byte)(g2 / n); dst[o] = (byte)(b2 / n);
                        }
                    }
                }
                Array.Copy(dst, src, src.Length);
            }
            System.Runtime.InteropServices.Marshal.Copy(src, 0, bd.Scan0, src.Length);
            bmp.UnlockBits(bd);
        }

        // ---------- MP4 文件头解析（WMP 读不到元数据时的兜底） ----------
        // 按 ISO BMFF box 树遍历（跳过 mdat 载荷，避免假命中）
        private static void FindBoxes(byte[] d, long start, long end, string target, List<long> hits)
        {
            long off = start;
            while (off + 8 <= end)
            {
                long size = ((long)d[off] << 24) | ((long)d[off + 1] << 16) | ((long)d[off + 2] << 8) | d[off + 3];
                if (size == 1 && off + 16 <= end)   // 64 位扩展大小
                {
                    size = ((long)d[off + 8] << 56) | ((long)d[off + 9] << 48) | ((long)d[off + 10] << 40) | ((long)d[off + 11] << 32)
                        | ((long)d[off + 12] << 24) | ((long)d[off + 13] << 16) | ((long)d[off + 14] << 8) | d[off + 15];
                }
                if (size < 8 || off + size > end) break;
                string t = "" + (char)d[off + 4] + (char)d[off + 5] + (char)d[off + 6] + (char)d[off + 7];
                if (t == target) hits.Add(off);
                // 容器 box 递归；mdat/free 等载荷直接跳过
                if (t != "mdat" && t != "free" && t != "skip" && t != "ftyp" && size > 8)
                    FindBoxes(d, off + 8, off + size, target, hits);
                off += size;
            }
        }
        private static long Be32(byte[] d, int x)
        {
            return ((long)d[x] << 24) | ((long)d[x + 1] << 16) | ((long)d[x + 2] << 8) | d[x + 3];
        }
        private static long Be64(byte[] d, int x)
        {
            return ((long)d[x] << 56) | ((long)d[x + 1] << 48) | ((long)d[x + 2] << 40) | ((long)d[x + 3] << 32)
                | ((long)d[x + 4] << 24) | ((long)d[x + 5] << 16) | ((long)d[x + 6] << 8) | d[x + 7];
        }
        // 从 avc1/hvc1 sample entry 读视频宽高
        private static Size ReadMp4Size(string path)
        {
            try
            {
                byte[] d = File.ReadAllBytes(path);
                List<long> hits = new List<long>();
                FindBoxes(d, 0, d.Length, "avc1", hits);
                if (hits.Count == 0) FindBoxes(d, 0, d.Length, "hvc1", hits);
                if (hits.Count > 0)
                {
                    long i = hits[0];
                    int w = (d[i + 24] << 8) | d[i + 25];
                    int h = (d[i + 26] << 8) | d[i + 27];
                    if (w > 0 && h > 0 && w <= 10000 && h <= 10000) return new Size(w, h);
                }
            }
            catch { }
            return Size.Empty;
        }
        // 从 mvhd box 读时长（秒）
        private static double ReadMp4Duration(string path)
        {
            try
            {
                byte[] d = File.ReadAllBytes(path);
                List<long> hits = new List<long>();
                FindBoxes(d, 0, d.Length, "mvhd", hits);
                foreach (long i in hits)
                {
                    int ver = d[i + 8];
                    long ts, dur;
                    if (ver == 1) { ts = Be32(d, (int)i + 28); dur = Be64(d, (int)i + 32); }
                    else { ts = Be32(d, (int)i + 20); dur = Be32(d, (int)i + 24); }
                    if (ts > 0)
                    {
                        double sec = (double)dur / ts;
                        if (sec > 0.5 && sec < 600) return sec;   // 合理时长范围校验，排除假命中
                    }
                }
            }
            catch { }
            return 0;
        }
        // 从 tkhd box 读轨道显示尺寸（16.16 定点数取整数部分；音频轨宽高为 0 自动跳过）
        private static Size ReadMp4DisplaySize(string path)
        {
            try
            {
                byte[] d = File.ReadAllBytes(path);
                List<long> hits = new List<long>();
                FindBoxes(d, 0, d.Length, "tkhd", hits);
                foreach (long i in hits)
                {
                    int ver = d[i + 8];
                    int off = ver == 1 ? 96 : 84;
                    if (i + off + 6 > d.Length) continue;
                    // width 整数部分 @off..off+1，height 整数部分 @off+4..off+5（16.16 定点）
                    int w = (d[i + off] << 8) | d[i + off + 1];
                    int h = (d[i + off + 4] << 8) | d[i + off + 5];
                    if (w > 0 && h > 0 && w <= 10000 && h <= 10000) return new Size(w, h);
                }
            }
            catch { }
            return Size.Empty;
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            ComputeLayout();
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.AntiAlias;

            using (SolidBrush bg = new SolidBrush(Color.FromArgb(6, 6, 8)))
                g.FillRectangle(bg, ClientRectangle);

            if (_paths == null || _paths.Length == 0)
            {
                // 视频模式：画面由 WMP 控件绘制；加载期间显示提示
                if (_videoMode && !_videoPlaying)
                {
                    string tip = "正在载入启动动画…";
                    using (Font f = new Font("Microsoft YaHei UI", 13f, FontStyle.Regular, GraphicsUnit.Point))
                    using (SolidBrush b = new SolidBrush(Color.FromArgb(170, 200, 215, 230)))
                    {
                        SizeF s = g.MeasureString(tip, f);
                        g.DrawString(tip, f, b, (Width - s.Width) / 2, (ClientSize.Height - s.Height) / 2 - 20);
                    }
                }
                return;
            }

            long t = Environment.TickCount - _t0;
            float breath = 0.65f + 0.35f * (float)Math.Sin(t / 420.0);

            using (Pen scan = new Pen(Color.FromArgb(10, 255, 255, 255)))
                for (int y = 0; y < ClientSize.Height; y += 4)
                    g.DrawLine(scan, 0, y, ClientSize.Width, y);

            using (Pen hud = new Pen(Color.FromArgb(46, AppConst.Amber)))
            {
                g.DrawLine(hud, 0, 0, ClientSize.Width, 0);
                g.DrawLine(hud, 0, ClientSize.Height - 1, ClientSize.Width, ClientSize.Height - 1);
            }

            int n = _paths.Length;
            int[] order = new int[n];
            for (int i = 0; i < n; i++) order[i] = i;
            Array.Sort(order, (a, b) => _bounds[a].X.CompareTo(_bounds[b].X));

            for (int k = 0; k < n; k++)
            {
                int i = order[k];
                float delay = PATH_DELAY_BASE + k * PATH_DELAY_STEP;
                float p = EaseInOutCubic((t - delay) / PATH_DUR);
                if (p <= 0f) continue;

                GraphicsPath path = _paths[i];
                RectangleF b = _bounds[i];
                Color col = LogoPaths.IsRed[i] ? AppConst.Red : AppConst.White;

                GraphicsState st = g.Save();
                g.TranslateTransform(_origin.X, _origin.Y);
                g.ScaleTransform(_scale, _scale);

                float revealW = b.Width * p;
                Region clip = new Region(new RectangleF(b.X, b.Y, revealW, b.Height + 2f));
                g.SetClip(clip, CombineMode.Replace);

                bool done = p >= 1f && t >= GLOW_AT;
                if (done && !_closing)
                    DrawGlow(g, path, col, breath, _scale);
                using (SolidBrush fb = new SolidBrush(col))
                    g.FillPath(fb, path);
                if (done)
                {
                    using (Pen edge = new Pen(Color.FromArgb((int)(150 * breath), col), 1.4f))
                        g.DrawPath(edge, path);
                }

                g.Restore(st);
                clip.Dispose();
            }

            if (_textStarted && !_closing)
            {
                string txt = "550C SYSTEM BOOT";
                string shown = txt.Substring(0, Math.Min(_textChars, txt.Length));
                bool blink = (t / 500) % 2 == 0;
                using (Font f = new Font("Consolas", 15f, FontStyle.Bold, GraphicsUnit.Point))
                {
                    SizeF sz = g.MeasureString(shown, f);
                    float tx = (ClientSize.Width - sz.Width) / 2f;
                    float ty = _origin.Y + 230f * _scale + 22f;
                    using (SolidBrush glowTxt = new SolidBrush(Color.FromArgb(70, AppConst.Amber)))
                        g.DrawString(shown, f, glowTxt, tx + 1.5f, ty + 1.5f);
                    using (SolidBrush tb = new SolidBrush(AppConst.Amber))
                        g.DrawString(shown, f, tb, tx, ty);
                    if (blink)
                    {
                        using (SolidBrush cursorB = new SolidBrush(AppConst.Amber))
                            g.FillRectangle(cursorB, tx + sz.Width + 4f, ty + 2f, 10f, f.Height);
                    }
                }
            }

            if (_closing)
            {
                using (SolidBrush fadeB = new SolidBrush(Color.FromArgb((int)(Math.Min(1f, _fade) * 255f), 6, 6, 8)))
                    g.FillRectangle(fadeB, ClientRectangle);
            }
        }

        private void DrawGlow(Graphics g, GraphicsPath path, Color c, float breath, float scale)
        {
            float baseW = 2.6f / scale;
            using (Pen p1 = new Pen(Color.FromArgb((int)(28 * breath), c), baseW * 5.5f)) { p1.LineJoin = LineJoin.Round; g.DrawPath(p1, path); }
            using (Pen p2 = new Pen(Color.FromArgb((int)(55 * breath), c), baseW * 2.8f)) { p2.LineJoin = LineJoin.Round; g.DrawPath(p2, path); }
            using (Pen p3 = new Pen(Color.FromArgb((int)(120 * breath), c), baseW * 1.1f)) { p3.LineJoin = LineJoin.Round; g.DrawPath(p3, path); }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_timer != null) _timer.Stop();
            if (_poll != null) _poll.Stop();
            if (_fadeTimer != null) _fadeTimer.Stop();
            if (_pulseTimer != null) _pulseTimer.Stop();
            if (_glassTimer != null) _glassTimer.Stop();
            if (_wmp != null)
            {
                try { dynamic p = _wmp.Player; p.controls.stop(); } catch { }
            }
            base.OnFormClosing(e);
        }
    }

    // ================= 玻璃卡片（不透明浅底 + 圆角 + 高光 + 悬停微浮 + 聚光灯） =================
    class GlassPanel : Panel
    {
        public int CornerRadius = 18;
        private float _animY = 1f;      // 入场进度 0..1（赋值即重绘，动画驱动必须可见）
        public float AnimY { get { return _animY; } set { _animY = value; Invalidate(); } }
        public float StartDelay = 0f;
        public float LiftTarget = 0f;   // 悬停微浮目标（主窗体驱动）
        public float Lift = 0f;         // 当前微浮值
        public float SpotX = 0.5f;      // 聚光灯位置（0..1 相对）
        public float SpotY = 0.5f;
        public bool SpotOn = false;     // 鼠标是否在卡片内

        // 背景浅色（与窗体背景协调，绝不透明）
        public static readonly Color CardBg = Color.FromArgb(246, 249, 253);

        public GlassPanel()
        {
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint, true);
            BackColor = CardBg;
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(CardBg);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            float ease = Ease.OutBack(Ease.Clamp01(AnimY));
            if (ease <= 0.01f) { g.Clear(CardBg); return; }

            GraphicsState st = g.Save();
            g.TranslateTransform(0, (int)((1f - ease) * 34f) - (int)(2.5f * Lift));

            Rectangle r = new Rectangle(0, 0, Width - 1, Height - 1);
            using (GraphicsPath gp = RoundedRect(r, CornerRadius))
            {
                // 主体（略高于卡片底色）
                using (SolidBrush fill = new SolidBrush(Color.FromArgb(252, 253, 255)))
                    g.FillPath(fill, gp);
                // 顶部高光
                Rectangle top = new Rectangle(0, 0, Width, Math.Max(14, Height / 2));
                using (GraphicsPath tp = RoundedRect(top, CornerRadius))
                using (LinearGradientBrush lg = new LinearGradientBrush(top, Color.FromArgb(140, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), 90f))
                    g.FillPath(lg, tp);
                // 聚光灯：高光跟随鼠标（React Bits SpotlightCard 效果）
                if (SpotOn && Lift > 0.05f)
                {
                    float sx = SpotX * Width, sy = SpotY * Height;
                    float sr = Math.Max(Width, Height) * 0.85f;
                    using (GraphicsPath sp = new GraphicsPath())
                    {
                        sp.AddEllipse(sx - sr / 2f, sy - sr / 2f, sr, sr);
                        g.SetClip(gp);
                        using (System.Drawing.Drawing2D.PathGradientBrush pgb = new System.Drawing.Drawing2D.PathGradientBrush(sp))
                        {
                            pgb.CenterColor = Color.FromArgb(85, 255, 255, 255);
                            pgb.SurroundColors = new Color[] { Color.FromArgb(0, 255, 255, 255) };
                            g.FillRectangle(pgb, 0, 0, Width, Height);
                        }
                        g.ResetClip();
                    }
                }
                // 描边（悬停更亮）
                int bA = Lift > 0.05f ? 235 : 215;
                using (Pen border = new Pen(Color.FromArgb(bA, Lift > 0.05f ? 176 : 225, Lift > 0.05f ? 196 : 238, 255), 1.2f))
                    g.DrawPath(border, gp);
            }
            g.Restore(st);
            base.OnPaint(e);
        }

        public static GraphicsPath RoundedRect(Rectangle r, int rad)
        {
            GraphicsPath gp = new GraphicsPath();
            if (rad <= 0 || r.Width <= 2 * rad || r.Height <= 2 * rad) { gp.AddRectangle(r); return gp; }
            int d = rad * 2;
            gp.AddArc(r.X, r.Y, d, d, 180, 90);
            gp.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            gp.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            gp.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            gp.CloseFigure();
            return gp;
        }
    }

    // ================= 缓动函数 =================
    static class Ease
    {
        public static float OutCubic(float p)
        {
            if (p <= 0f) return 0f;
            if (p >= 1f) return 1f;
            float q = 1f - p;
            return 1f - q * q * q;
        }
        // 回弹（overshoot）：冲过目标再弹回，丝滑生动
        public static float OutBack(float p)
        {
            if (p <= 0f) return 0f;
            if (p >= 1f) return 1f;
            const float c1 = 1.70158f, c3 = c1 + 1f;
            float q = p - 1f;
            return 1f + c3 * q * q * q + c1 * q * q;
        }
        public static float InOutCubic(float p)
        {
            if (p <= 0f) return 0f;
            if (p >= 1f) return 1f;
            if (p < 0.5f) return 4f * p * p * p;
            float q = -2f * p + 2f;
            return 1f - q * q * q / 2f;
        }
        // 弹簧物理曲线（iOS Motion Spring）：阻尼振荡过冲，生动自然
        public static float Spring(float p)
        {
            if (p <= 0f) return 0f;
            if (p >= 1f) return 1f;
            float x = p * 5f;
            return (float)(1.0 - Math.Cos(x * Math.PI / 2.0) * Math.Exp(-x * 0.9));
        }
        public static float Clamp01(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }
    }

    // ================= 玻璃按钮（原生 Button 基类 + 点击回弹 + 悬停缩放发光 + 入场） =================
    class GlassButton : Button
    {
        public int CornerRadius = 13;
        public bool Primary = false;
        public float AnimY = 1f;
        public float StartDelay = 0f;
        private float _hoverT = 0f;
        private float _pressT = 1f;     // 点击回弹进度（松开后 0→1）
        private float _pulse = 0f;      // 全局动画时间（呼吸/光泽用）
        public float MagX = 0f, MagY = 0f;  // 磁性吸附偏移（像素）

        public GlassButton()
        {
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint, true);
            BackColor = Color.FromArgb(243, 246, 250);
            ForeColor = Color.White;
            Font = new Font("Microsoft YaHei UI", 9.5f, FontStyle.Regular, GraphicsUnit.Point);
            Cursor = Cursors.Hand;
            FlatStyle = FlatStyle.Flat;
            TabStop = true;
            Height = 42;
        }

        public void UpdateAnim(float timeNow)
        {
            _pulse = timeNow;
            float target = timeNow >= StartDelay ? 1f : 0f;
            float targetH = _hover ? 1f : 0f;
            AnimY += (target - AnimY) * 0.14f;
            _hoverT += (targetH - _hoverT) * 0.22f;
            // 按住保持压扁，松开后回弹
            if (_down) _pressT = 0f;
            else if (_pressT < 1f) _pressT += 0.11f;
            Invalidate();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(Color.FromArgb(243, 246, 250));
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;

            float ease = Ease.OutBack(Ease.Clamp01(AnimY));
            if (ease <= 0.01f) { g.Clear(Color.FromArgb(243, 246, 250)); return; }

            Rectangle r = new Rectangle(0, 0, Width - 1, Height - 1);
            GraphicsState st = g.Save();
            g.TranslateTransform(0, (int)((1f - ease) * 24f));
            // 磁性吸附（仅悬停时，向鼠标方向微移）
            g.TranslateTransform(MagX * 0.4f * _hoverT, MagY * 0.4f * _hoverT);
            // 点击回弹：按下压扁 → 松开弹起过冲回落
            float bounce = 0.92f + 0.085f * Ease.OutBack(Ease.Clamp01(_pressT));
            float scale = bounce * (1f + 0.05f * _hoverT);
            if (scale != 1f)
            {
                g.TranslateTransform(Width / 2f, Height / 2f);
                g.ScaleTransform(scale, scale);
                g.TranslateTransform(-Width / 2f, -Height / 2f);
            }

            using (GraphicsPath gp = GlassPanel.RoundedRect(r, CornerRadius))
            {
                if (Primary)
                {
                    // 常驻呼吸光晕（吸引注意，动效关闭时跳过）
                    if (AppConst.AnimEnabled)
                    {
                        float pulse = 0.55f + 0.45f * (float)Math.Sin(_pulse * 2.2f);
                        using (Pen glow0 = new Pen(Color.FromArgb((int)(42 * pulse), 96, 166, 250), 4f))
                            g.DrawPath(glow0, gp);
                    }
                    // 悬停强光晕
                    if (_hoverT > 0.05f)
                    {
                        using (Pen glow = new Pen(Color.FromArgb((int)(70 * _hoverT), 96, 166, 250), 9f))
                            g.DrawPath(glow, gp);
                        using (Pen glow2 = new Pen(Color.FromArgb((int)(120 * _hoverT), 96, 166, 250), 3f))
                            g.DrawPath(glow2, gp);
                    }
                    Color c1 = _hover ? Color.FromArgb(104, 172, 252) : Color.FromArgb(79, 157, 247);
                    Color c2 = _hover ? Color.FromArgb(56, 132, 230) : Color.FromArgb(37, 106, 208);
                    using (LinearGradientBrush lg = new LinearGradientBrush(r, c1, c2, 90f))
                        g.FillPath(lg, gp);
                    using (Pen border = new Pen(Color.FromArgb(200, 255, 255, 255), 1f))
                        g.DrawPath(border, gp);
                    // 悬停光泽扫过
                    if (_hoverT > 0.05f)
                    {
                        float shp = (float)((_pulse * 0.55f) % 1.0f);
                        int shx = -30 + (int)(shp * (Width + 60));
                        Rectangle shR = new Rectangle(shx, 0, 26, Height);
                        g.SetClip(gp);
                        using (LinearGradientBrush shb = new LinearGradientBrush(shR, Color.FromArgb(0, 255, 255, 255), Color.FromArgb(120, 255, 255, 255), 0f))
                            g.FillRectangle(shb, shR);
                        g.ResetClip();
                    }
                }
                else
                {
                    using (SolidBrush fill = new SolidBrush(_hover ? Color.FromArgb(255, 255, 255) : Color.FromArgb(250, 251, 253)))
                        g.FillPath(fill, gp);
                    using (LinearGradientBrush lg = new LinearGradientBrush(r, Color.FromArgb(90, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), 90f))
                        g.FillPath(lg, gp);
                    using (Pen border = new Pen(Color.FromArgb(_hover ? 205 : 165, 196, 210, 228), 1f))
                        g.DrawPath(border, gp);
                    // 悬停光泽扫过
                    if (_hoverT > 0.05f)
                    {
                        float shp = (float)((_pulse * 0.55f) % 1.0f);
                        int shx = -30 + (int)(shp * (Width + 60));
                        Rectangle shR = new Rectangle(shx, 0, 26, Height);
                        g.SetClip(gp);
                        using (LinearGradientBrush shb = new LinearGradientBrush(shR, Color.FromArgb(0, 255, 255, 255), Color.FromArgb(120, 255, 255, 255), 0f))
                            g.FillRectangle(shb, shR);
                        g.ResetClip();
                    }
                }
            }
            Color fc = Primary ? Color.White : AppConst.TextDark;
            int ty = _down ? 1 : (_hover ? -1 : 0);
            Rectangle tr = new Rectangle(0, ty, Width, Height);
            TextRenderer.DrawText(g, Text, Font, tr, fc, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
            g.Restore(st);
        }

        private bool _hover, _down;
        protected override void OnMouseEnter(EventArgs e) { _hover = true; base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; _down = false; MagX = 0f; MagY = 0f; base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { _down = true; _pressT = 0f; base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { _down = false; base.OnMouseUp(e); }
        protected override void OnMouseMove(MouseEventArgs e)
        {
            MagX = Math.Max(-8f, Math.Min(8f, e.X - Width / 2f));
            MagY = Math.Max(-8f, Math.Min(8f, e.Y - Height / 2f));
            base.OnMouseMove(e);
        }
    }

    // ================= 进程列表（不透明浅底 + 逐行浮现 + 悬停高亮 + 状态呼吸） =================
    class ProcList : Control
    {
        public string[] Procs;
        public string[] Disp;
        public bool[] Running;
        public int Selected = -1;
        public int RowH = 58;
        public int Gap = 6;
        public float AnimTime = 1f;
        private int _hoverIdx = -1;

        public ProcList()
        {
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint, true);
            BackColor = Color.FromArgb(250, 252, 254);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(Color.FromArgb(250, 252, 254));
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
            if (Procs == null) return;

            for (int i = 0; i < Procs.Length; i++)
            {
                float rowT = Ease.Clamp01((AnimTime - 0.35f - i * 0.07f) / 0.45f);
                float rowEase = Ease.OutBack(rowT);
                if (rowEase <= 0.01f) continue;
                int yOff = (int)((1f - rowEase) * 22f);

                Rectangle r = new Rectangle(1, i * (RowH + Gap) + yOff, Width - 2, RowH);
                bool sel = (i == Selected);
                bool hov = (i == _hoverIdx);
                using (GraphicsPath gp = GlassPanel.RoundedRect(r, 12))
                {
                    if (sel)
                    {
                        using (SolidBrush fill = new SolidBrush(Color.FromArgb(236, 242, 250)))
                            g.FillPath(fill, gp);
                        // 选中行呼吸描边
                        float br = 0.72f + 0.28f * (float)Math.Sin(AnimTime * 3.2 + i);
                        using (Pen sp = new Pen(Color.FromArgb((int)(205 * br), 112, 170, 240), 1.5f))
                            g.DrawPath(sp, gp);
                    }
                    else if (hov)
                    {
                        using (SolidBrush fill = new SolidBrush(Color.FromArgb(243, 247, 252)))
                            g.FillPath(fill, gp);
                    }
                    else
                    {
                        using (SolidBrush fill = new SolidBrush(Color.FromArgb(253, 254, 255)))
                            g.FillPath(fill, gp);
                    }
                    // 指示条脉动
                    if (hov || sel)
                    {
                        float ia = 200f + 55f * (float)Math.Sin(AnimTime * 3.6 + i * 1.2);
                        using (SolidBrush ind = new SolidBrush(Color.FromArgb((int)ia, 96, 158, 238)))
                            g.FillRectangle(ind, 1, r.Y + 12, 3, r.Height - 24);
                    }
                }
                bool run = Running != null && i < Running.Length && Running[i];
                float pulse = AppConst.AnimEnabled && run ? (0.72f + 0.28f * (float)Math.Sin(AnimTime * 4.2 + i * 1.1)) : 1f;
                Color dot = run ? Color.FromArgb((int)(240 * pulse), 240, 82, 82) : Color.FromArgb(63, 174, 106);
                int cy = r.Y + r.Height / 2;
                // 运行中：涟漪扩散环（动效关闭时跳过）
                if (run && AppConst.AnimEnabled)
                {
                    float ri = (AnimTime * 0.9f + i * 0.37f) % 1f;
                    float rad = 6 + ri * 15f;
                    int ra = (int)(150 * (1f - ri));
                    using (Pen rp = new Pen(Color.FromArgb(ra, 240, 82, 82), 1.6f))
                        g.DrawEllipse(rp, 23 - rad, cy - rad, rad * 2, rad * 2);
                }
                using (SolidBrush dotB = new SolidBrush(dot))
                    g.FillEllipse(dotB, 18, cy - 5, 10, 10);
                using (Pen dotP = new Pen(Color.FromArgb(150, 255, 255, 255), 1f))
                    g.DrawEllipse(dotP, 18, cy - 5, 10, 10);
                using (Font f1 = new Font("Consolas", 9.5f, FontStyle.Bold, GraphicsUnit.Point))
                using (SolidBrush b1 = new SolidBrush(AppConst.TextDark))
                    g.DrawString(Procs[i], f1, b1, 38, r.Y + 7);
                if (Disp != null && i < Disp.Length)
                {
                    using (Font f2 = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Regular, GraphicsUnit.Point))
                    using (SolidBrush b2 = new SolidBrush(AppConst.TextSub))
                        g.DrawString(Disp[i], f2, b2, 38, r.Y + 27);
                }
                string st = run ? "运行中" : "已停止";
                Color stc = run ? Color.FromArgb(224, 70, 70) : Color.FromArgb(58, 150, 98);
                using (Font f3 = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Regular, GraphicsUnit.Point))
                using (SolidBrush b3 = new SolidBrush(stc))
                {
                    SizeF sz = g.MeasureString(st, f3);
                    g.DrawString(st, f3, b3, Width - sz.Width - 18, r.Y + r.Height / 2 - 8);
                }
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int idx = e.Y / (RowH + Gap);
            int max = (Procs == null ? 0 : Procs.Length);
            if (idx != _hoverIdx && idx >= 0 && idx < max) { _hoverIdx = idx; Invalidate(); }
            else if (idx < 0 || idx >= max) { if (_hoverIdx != -1) { _hoverIdx = -1; Invalidate(); } }
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            if (_hoverIdx != -1) { _hoverIdx = -1; Invalidate(); }
            base.OnMouseLeave(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            int idx = e.Y / (RowH + Gap);
            if (idx >= 0 && idx < (Procs == null ? 0 : Procs.Length))
            {
                Selected = idx;
                Invalidate();
            }
            base.OnMouseDown(e);
        }
    }

    // ================= 日志列表（自绘，逐行滑入淡入 + 滚轮滚动） =================
    class LogLine
    {
        public string Time, Text;
        public float Born;      // 加入时的动画时间
        public Color C;
    }

    class LogList : Control
    {
        public List<LogLine> Lines = new List<LogLine>();
        public float AnimTime = 0f;     // 与全局动画时间同步（从 0 开始）
        public int LineH = 24;
        private int _offset = 0;      // 向上滚动的行数
        private bool _follow = true;  // 自动跟随底部

        public LogList()
        {
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint, true);
            BackColor = Color.FromArgb(250, 252, 254);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(BackColor);
        }

        public void Add(string time, string text, Color c)
        {
            Lines.Add(new LogLine { Time = time, Text = text, Born = AnimTime, C = c });
            if (Lines.Count > 400) Lines.RemoveAt(0);
            if (_follow) ScrollToBottom();
            Invalidate();
        }

        public void ScrollToBottom()
        {
            int rows = Math.Max(1, Height / LineH);
            _offset = Math.Max(0, Lines.Count - rows);
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
            int rows = Math.Max(1, Height / LineH);
            int start = Math.Max(0, Lines.Count - rows - _offset);
            int newestIdx = Lines.Count - 1;

            using (Font f1 = new Font("Consolas", 8.5f, FontStyle.Bold, GraphicsUnit.Point))
            using (Font f2 = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Regular, GraphicsUnit.Point))
            {
                for (int i = start; i < Lines.Count; i++)
                {
                    LogLine ln = Lines[i];
                    int fromBottom = newestIdx - i;
                    int yBase = Height - (fromBottom + 1) * LineH;
                    if (yBase + LineH < 0 || yBase > Height) continue;

                    int alpha = 255;
                    int yOff = 0;
                    // 最新几行滑入淡入
                    if (fromBottom <= 5 && AnimTime - ln.Born < 0.6f)
                    {
                        float t = Ease.Clamp01((AnimTime - ln.Born) / 0.45f);
                        float ease = Ease.OutCubic(t);
                        if (ease <= 0.01f) continue;
                        alpha = (int)(255 * ease);
                        yOff = (int)((1f - ease) * 16f);
                    }
                    int y = yBase + yOff;
                    using (SolidBrush b1 = new SolidBrush(Color.FromArgb(alpha, 138, 150, 166)))
                        g.DrawString(ln.Time, f1, b1, 6, y + 4);
                    using (SolidBrush b2 = new SolidBrush(Color.FromArgb(alpha, ln.C.R, ln.C.G, ln.C.B)))
                        g.DrawString(ln.Text, f2, b2, 62, y + 4);
                }
            }
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            _follow = false;
            int rows = Math.Max(1, Height / LineH);
            int maxOffset = Math.Max(0, Lines.Count - rows);
            int delta = e.Delta > 0 ? 2 : -2;
            _offset = Math.Max(0, Math.Min(maxOffset, _offset + delta));
            Invalidate();
            base.OnMouseWheel(e);
        }
    }

    // ================= 修复步骤列表（恢复硬盘/解除限制，状态动画） =================
    class FixList : Control
    {
        public string[] Names;      // 步骤名
        public string[] Desc;       // 说明
        public int[] State;         // 0待执行 1执行中 2成功 3失败
        public int RowH = 58;
        public int Gap = 6;
        public float AnimTime = 1f;
        private int _hoverIdx = -1;

        public FixList()
        {
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint, true);
            BackColor = Color.FromArgb(250, 252, 254);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(Color.FromArgb(250, 252, 254));
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
            if (Names == null) return;

            for (int i = 0; i < Names.Length; i++)
            {
                float rowT = Ease.Clamp01((AnimTime - 0.30f - i * 0.07f) / 0.45f);
                float rowEase = Ease.OutBack(rowT);
                if (rowEase <= 0.01f) continue;
                int yOff = (int)((1f - rowEase) * 20f);

                Rectangle r = new Rectangle(1, i * (RowH + Gap) + yOff, Width - 2, RowH);
                bool hov = (i == _hoverIdx);
                using (GraphicsPath gp = GlassPanel.RoundedRect(r, 12))
                {
                    using (SolidBrush fill = new SolidBrush(hov ? Color.FromArgb(243, 247, 252) : Color.FromArgb(253, 254, 255)))
                        g.FillPath(fill, gp);
                    if (hov)
                    {
                        float ia = 200f + 55f * (float)Math.Sin(AnimTime * 3.6 + i * 1.2);
                        using (SolidBrush ind = new SolidBrush(Color.FromArgb((int)ia, 96, 158, 238)))
                            g.FillRectangle(ind, 1, r.Y + 12, 3, r.Height - 24);
                    }
                }

                // 状态点（待执行灰 / 执行中橙呼吸 / 成功绿 / 失败红）
                int st = State != null && i < State.Length ? State[i] : 0;
                int cy = r.Y + r.Height / 2;
                Color dot;
                string stText;
                if (st == 1)
                {
                    float p = AppConst.AnimEnabled ? (0.55f + 0.45f * (float)Math.Sin(AnimTime * 5.0f)) : 1f;
                    dot = Color.FromArgb((int)(240 * p), 240, 160, 60);
                    stText = "执行中…";
                    if (AppConst.AnimEnabled)
                    {
                        float ri = (AnimTime * 1.1f) % 1f;
                        float rad = 6 + ri * 16f;
                        int ra = (int)(160 * (1f - ri));
                        using (Pen rp = new Pen(Color.FromArgb(ra, 240, 160, 60), 1.6f))
                            g.DrawEllipse(rp, 23 - rad, cy - rad, rad * 2, rad * 2);
                    }
                }
                else if (st == 2) { dot = Color.FromArgb(63, 174, 106); stText = "已完成"; }
                else if (st == 3) { dot = Color.FromArgb(228, 90, 80); stText = "失败"; }
                else if (st == 4) { dot = Color.FromArgb(150, 158, 172); stText = "已取消"; }
                else { dot = Color.FromArgb(158, 170, 186); stText = "待执行"; }

                using (SolidBrush dotB = new SolidBrush(dot))
                    g.FillEllipse(dotB, 18, cy - 5, 10, 10);
                using (Pen dotP = new Pen(Color.FromArgb(150, 255, 255, 255), 1f))
                    g.DrawEllipse(dotP, 18, cy - 5, 10, 10);
                using (Font f1 = new Font("Microsoft YaHei UI", 9.5f, FontStyle.Bold, GraphicsUnit.Point))
                using (SolidBrush b1 = new SolidBrush(AppConst.TextDark))
                    g.DrawString(Names[i], f1, b1, 38, r.Y + 7);
                if (Desc != null && i < Desc.Length)
                {
                    using (Font f2 = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Regular, GraphicsUnit.Point))
                    using (SolidBrush b2 = new SolidBrush(AppConst.TextSub))
                        g.DrawString(Desc[i], f2, b2, 38, r.Y + 27);
                }
                Color stc = st == 2 ? Color.FromArgb(58, 150, 98) : (st == 3 ? Color.FromArgb(220, 70, 60) : (st == 1 ? Color.FromArgb(228, 140, 40) : (st == 4 ? Color.FromArgb(128, 140, 156) : Color.FromArgb(138, 150, 166))));
                using (Font f3 = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Regular, GraphicsUnit.Point))
                using (SolidBrush b3 = new SolidBrush(stc))
                {
                    SizeF sz = g.MeasureString(stText, f3);
                    g.DrawString(stText, f3, b3, Width - sz.Width - 18, r.Y + r.Height / 2 - 8);
                }
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int idx = e.Y / (RowH + Gap);
            int max = (Names == null ? 0 : Names.Length);
            if (idx != _hoverIdx && idx >= 0 && idx < max) { _hoverIdx = idx; Invalidate(); }
            else if (idx < 0 || idx >= max) { if (_hoverIdx != -1) { _hoverIdx = -1; Invalidate(); } }
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            if (_hoverIdx != -1) { _hoverIdx = -1; Invalidate(); }
            base.OnMouseLeave(e);
        }
    }

    // ================= iOS 26 药丸开关（弹簧动画 + 按压拉伸，源自 IOS26PillControls） =================
    class PillSwitch : Control
    {
        public bool Checked = false;
        public event Action<bool> Changed;
        private float _animT = 0f;     // 0=关 1=开（线性推进）
        private bool _pressed = false;

        public PillSwitch()
        {
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint, true);
            BackColor = Color.FromArgb(252, 253, 255);
            Height = 36;
            Cursor = Cursors.Hand;
        }

        public void UpdateAnim()
        {
            float target = Checked ? 1f : 0f;
            _animT += (target - _animT) * 0.16f;
            Invalidate();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(BackColor);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // 文字
            if (!string.IsNullOrEmpty(Text))
            {
                using (Font f = new Font("Microsoft YaHei UI", 9f, FontStyle.Regular, GraphicsUnit.Point))
                using (SolidBrush b = new SolidBrush(AppConst.TextDark))
                    g.DrawString(Text, f, b, 2, (Height - 18) / 2 + 1);
            }

            // 轨道（右端）
            int tw = 46, th = 22;
            Rectangle track = new Rectangle(Width - tw - 2, (Height - th) / 2, tw, th);
            float k = Ease.Clamp01(Ease.Spring(_animT));
            using (GraphicsPath tp = GlassPanel.RoundedRect(track, th / 2))
            {
                if (k > 0.02f)
                {
                    Color c1 = Color.FromArgb(96, 166, 250);
                    Color c2 = Color.FromArgb(47, 127, 224);
                    using (LinearGradientBrush lg = new LinearGradientBrush(track, c1, c2, 90f))
                        g.FillPath(lg, tp);
                }
                else
                {
                    using (SolidBrush off = new SolidBrush(Color.FromArgb(226, 232, 240)))
                        g.FillPath(off, tp);
                }
                using (Pen tb = new Pen(Color.FromArgb(90, 255, 255, 255), 1f))
                    g.DrawPath(tb, tp);
            }

            // 滑块（按压拉伸：按下时变宽，形成 iOS 拉长感）
            int slide = 16 + (_pressed ? 5 : 0);
            int sx = (int)(track.X + 2 + (track.Width - 4 - slide) * k);
            int sy = (Height - slide) / 2;
            // 滑块阴影
            using (SolidBrush sh = new SolidBrush(Color.FromArgb(30, 40, 60, 90)))
                g.FillEllipse(sh, sx + 1, sy + 1, slide, slide);
            using (SolidBrush wb = new SolidBrush(Color.White))
                g.FillEllipse(wb, sx, sy, slide, slide);
            using (Pen wp = new Pen(Color.FromArgb(80, 210, 218, 228), 1f))
                g.DrawEllipse(wp, sx, sy, slide, slide);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            _pressed = true;
            Invalidate();
            base.OnMouseDown(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            _pressed = false;
            bool inside = ClientRectangle.Contains(e.Location);
            if (inside)
            {
                Checked = !Checked;
                if (Changed != null) Changed(Checked);
            }
            Invalidate();
            base.OnMouseUp(e);
        }
    }

    // ================= 左侧导航栏（多分区页面切换） =================
    class NavBar : Control
    {
        public int Selected = 0;
        public string[] Titles = { "进程清理", "恢复硬盘", "更新日志", "关于", "设置" };
        public string[] Subs = { "守护进程一键清理", "盘符与限制解除", "版本更新记录", "应用信息与致谢", "动画与外观选项" };
        public Color[] Icons = { Color.FromArgb(96, 166, 250), Color.FromArgb(64, 192, 140), Color.FromArgb(250, 190, 80), Color.FromArgb(168, 130, 250), Color.FromArgb(245, 158, 74) };
        public int ItemH = 62;
        private int _hoverIdx = -1;

        public NavBar()
        {
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint, true);
            BackColor = Color.FromArgb(242, 246, 251);
            Cursor = Cursors.Hand;
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle r = new Rectangle(0, 0, Width - 1, Height - 1);
            using (GraphicsPath gp = GlassPanel.RoundedRect(r, 0))
            {
                using (SolidBrush fill = new SolidBrush(Color.FromArgb(242, 246, 251)))
                    g.FillPath(fill, gp);
                using (Pen border = new Pen(Color.FromArgb(226, 233, 243), 1f))
                    g.DrawLine(border, Width - 1, 0, Width - 1, Height);
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;

            // 顶部品牌
            using (Font f0 = new Font("Microsoft YaHei UI", 10.5f, FontStyle.Bold, GraphicsUnit.Point))
            using (SolidBrush b0 = new SolidBrush(AppConst.TextDark))
                g.DrawString("云守护工具", f0, b0, 18, 20);
            using (Font f01 = new Font("Consolas", 7.5f, FontStyle.Regular, GraphicsUnit.Point))
            using (SolidBrush b01 = new SolidBrush(AppConst.TextSub))
                g.DrawString("OKK GUARDIAN", f01, b01, 18, 44);

            int y = 74;
            for (int i = 0; i < Titles.Length; i++)
            {
                Rectangle ir = new Rectangle(10, y, Width - 20, ItemH);
                bool sel = (i == Selected);
                bool hov = (i == _hoverIdx);
                using (GraphicsPath gp = GlassPanel.RoundedRect(ir, 12))
                {
                    if (sel)
                    {
                        using (SolidBrush fill = new SolidBrush(Color.FromArgb(224, 234, 248)))
                            g.FillPath(fill, gp);
                        using (Pen bp = new Pen(Color.FromArgb(190, 112, 170, 240), 1.4f))
                            g.DrawPath(bp, gp);
                        using (SolidBrush ind = new SolidBrush(Color.FromArgb(230, 96, 158, 238)))
                            g.FillRectangle(ind, 10, y + 14, 3, ItemH - 28);
                    }
                    else if (hov)
                    {
                        using (SolidBrush fill = new SolidBrush(Color.FromArgb(234, 239, 246)))
                            g.FillPath(fill, gp);
                    }
                }
                // 图标块
                Rectangle ic = new Rectangle(28, y + 18, 12, 12);
                using (SolidBrush ib = new SolidBrush(Icons[i]))
                    g.FillEllipse(ib, ic);
                using (SolidBrush ih = new SolidBrush(Color.FromArgb(160, 255, 255, 255)))
                    g.FillEllipse(ih, new Rectangle(ic.X + 2, ic.Y + 2, 4, 4));
                using (Font f1 = new Font("Microsoft YaHei UI", 9.5f, FontStyle.Bold, GraphicsUnit.Point))
                using (SolidBrush b1 = new SolidBrush(sel ? AppConst.TextDark : Color.FromArgb(96, 108, 124)))
                    g.DrawString(Titles[i], f1, b1, 50, y + 7);
                using (Font f2 = new Font("Microsoft YaHei UI", 7.5f, FontStyle.Regular, GraphicsUnit.Point))
                using (SolidBrush b2 = new SolidBrush(AppConst.TextSub))
                    g.DrawString(Subs[i], f2, b2, 50, y + 30);
                y += ItemH + 6;
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int idx = (e.Y - 74) / (ItemH + 6);
            int max = Titles.Length;
            if (idx != _hoverIdx && idx >= 0 && idx < max) { _hoverIdx = idx; Invalidate(); }
            else if (idx < 0 || idx >= max) { if (_hoverIdx != -1) { _hoverIdx = -1; Invalidate(); } }
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            if (_hoverIdx != -1) { _hoverIdx = -1; Invalidate(); }
            base.OnMouseLeave(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            int idx = (e.Y - 74) / (ItemH + 6);
            if (idx >= 0 && idx < Titles.Length)
            {
                Selected = idx;
                Invalidate();
                if (ItemClicked != null) ItemClicked(idx);
            }
            base.OnMouseDown(e);
        }

        public event Action<int> ItemClicked;
    }

    // ================= 主窗体（浅色液态 + Aurora + 粒子 + 回弹 + 聚光 + 磁性 + 涟漪 + 拖尾） =================
    class Ripple
    {
        public float X, Y, T;
    }

    class MainForm : Form, IMessageFilter
    {
        private Image _bgImage;
        private ProcList _procList;
        private bool[] _running;
        private LogList _logList;
        private GlassPanel _cardProcs, _cardLog;
        private GlassButton _btnKill, _btnRefresh, _btnBg, _btnClearBg;
        private NavBar _navBar;
        private GlassPanel _cardFix;
        private FixList _fixList;
        private int[] _fixStates;
        private LogList _fixLog;
        private GlassButton _btnFix;
        private int _pageIndex = 0;
        private Rectangle _dragRect;
        private Button _btnMin, _btnClose;
        private System.Windows.Forms.Timer _clockTimer, _animTimer;
        private float _animTime = 0f;
        private float _pageSwitchTime = 0f;
        private string _lastKill = "—";
        private List<Ripple> _ripples = new List<Ripple>();
        private List<PointF> _trail = new List<PointF>();
        // 真·液态玻璃背景（桌面实时模糊）
        private Bitmap _glassBmp = null;
        private System.Windows.Forms.Timer _blurTimer;
        private bool _glassDirty = true;
        private bool _restartExplorer = true;
        private PillSwitch _swRestart;
        private bool _fixRunning = false;
        private bool _fixCancel = false;
        private GlassButton _btnCancelFix;
        // 设置页（页面5）
        private GlassPanel _cardSettings;
        private GlassButton _btnBoot550, _btnBootVideo, _btnSaveSettings;
        private PillSwitch _swBootProgress, _swAutostart, _swTopmost, _swAnim;
        private string _bootMode = "550c";
        private bool _animEnabled = true;
        // 更新日志（页面3）与关于（页面4）
        private GlassPanel _cardUpdate, _cardAbout;
        private Label _lblOwner;   // 右上角专属卡欢迎语
        private bool _expireWarning = false;   // 到期弹窗防重复标记
        private Label _toast;
        private int _toastUntil = 0;
        private float _fadeIn = 0f;

        public MainForm()
        {
            Text = "云电脑守护清理";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(1060, 640);
            MinimumSize = new Size(920, 560);
            BackColor = Color.FromArgb(235, 240, 248);
            DoubleBuffered = true;
            Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Regular, GraphicsUnit.Point);

            LoadBgFromCfg();
            BuildUI();
            RefreshProcs();

            _clockTimer = new System.Windows.Forms.Timer();
            _clockTimer.Interval = 1000;
            _clockTimer.Tick += (s, e) => { Invalidate(); RefreshOwner(); };   // 每秒刷新时钟 + 卡密到期倒计时
            _clockTimer.Start();

            // 全局动效引擎：驱动 Aurora 背景、卡片/按钮入场、列表逐行浮现
            _animTimer = new System.Windows.Forms.Timer();
            _animTimer.Interval = 16;
            _animTimer.Tick += AnimTick;
            _animTimer.Start();

            // 真·液态玻璃：低频捕捉桌面并模糊（窗体移动/后台变化时刷新）
            _blurTimer = new System.Windows.Forms.Timer();
            _blurTimer.Interval = 450;
            _blurTimer.Tick += (s, e) =>
            {
                if (_bgImage != null) return;   // 有自定义背景图时不用玻璃
                if (_glassDirty)
                {
                    CaptureGlass();
                    Invalidate();
                }
            };
            _blurTimer.Start();
            CaptureGlass();

            // 全局点击捕获：任意位置点击泛起涟漪（React Bits Ripple 效果）
            Application.AddMessageFilter(this);

            // 主窗体淡入（衔接启动动画）：初始透明，AnimTick 逐步加亮
            Opacity = 0f;
            _fadeIn = 0f;
            _toast = new Label();
            _toast.AutoSize = false;
            _toast.TextAlign = ContentAlignment.MiddleCenter;
            _toast.ForeColor = Color.White;
            _toast.BackColor = Color.FromArgb(205, 24, 26, 34);
            _toast.Font = new Font("Microsoft YaHei UI", 10f, FontStyle.Bold, GraphicsUnit.Point);
            _toast.Bounds = new Rectangle((ClientSize.Width - 300) / 2, ClientSize.Height - 44, 300, 32);
            _toast.Visible = false;
            Controls.Add(_toast);
            _toast.BringToFront();

            // 打开后自动静默清理黑名单进程 + 自动解除文件管理员限制
            Shown += (s, e) =>
            {
                System.Threading.Thread th = new System.Threading.Thread(delegate ()
                {
                    BootForm.KillBlockersOnce();
                    AutoUnlockLimits();
                });
                th.IsBackground = true;
                th.Start();
            };
            // 激活复核：已激活时后台联网/本地重新校验卡密，失效或过期则强制重新激活
            Shown += (s, e) => VerifyActivation();
        }

        // 每次启动复核激活状态：改 cfg activated=1 绕过无效；卡密到期/失效会被弹回激活窗
        private void VerifyActivation()
        {
            try
            {
                if (AppConst.GetCfg("activated", "0") != "1") return;
                System.Threading.Thread th = new System.Threading.Thread(delegate ()
                {
                    try
                    {
                        string key = AppConst.GetCfg("activated_key", "").Trim();
                        int st = -1;
                        string name = "";
                        if (key.Length > 0)
                        {
                            // 复核只认云端（服务器），不回退本地 keys
                            st = CardKey.CheckServer(key, out name);
                        }
                        if (st == -1 || st == 2)
                        {
                            BeginInvoke((MethodInvoker)delegate ()
                            {
                                try
                                {
                                    AppConst.Log("激活复核失败（" + (st == 2 ? "卡密已到期" : "卡密失效") + "），强制重新激活");
                                    ShowToast("激活已失效，请重新输入卡密");
                                    using (ActivateForm af = new ActivateForm())
                                    {
                                        if (af.ShowDialog() != DialogResult.OK) { Close(); return; }
                                        ShowToast("激活成功，欢迎使用");
                                    }
                                }
                                catch { }
                            });
                        }
                    }
                    catch { }
                });
                th.IsBackground = true;
                th.Start();
            }
            catch { }
        }

        private void ShowToast(string text)
        {
            if (_toast == null) return;
            _toast.Text = text;
            _toast.Visible = true;
            _toast.BringToFront();
            _toastUntil = Environment.TickCount + 2600;
        }

        protected override void OnMove(EventArgs e)
        {
            base.OnMove(e);
            _glassDirty = true;
        }

        // 捕获窗口内任意 WM_LBUTTONDOWN（含子控件），记录涟漪
        public bool PreFilterMessage(ref Message m)
        {
            if (m.Msg == 0x0201)
            {
                Point pt = PointToClient(Cursor.Position);
                if (ClientRectangle.Contains(pt))
                {
                    _ripples.Add(new Ripple { X = pt.X, Y = pt.Y, T = _animTime });
                    if (_ripples.Count > 12) _ripples.RemoveAt(0);
                }
            }
            return false;
        }

        private void AnimTick(object sender, EventArgs e)
        {
            _animTime += 0.016f;
            float t = _animTime;
            float pt = t - _pageSwitchTime;   // 距上次页面切换的相对时间
            if (_cardProcs != null) _cardProcs.AnimY = Ease.OutBack(Ease.Clamp01((pt - 0.10f) / 0.7f));
            if (_cardLog != null) _cardLog.AnimY = Ease.OutBack(Ease.Clamp01((pt - 0.22f) / 0.7f));
            if (_cardFix != null && _pageIndex == 1) _cardFix.AnimY = Ease.OutBack(Ease.Clamp01((pt - 0.10f) / 0.7f));
            if (_cardUpdate != null && _pageIndex == 2) _cardUpdate.AnimY = Ease.OutBack(Ease.Clamp01((pt - 0.10f) / 0.7f));
            if (_cardAbout != null && _pageIndex == 3) _cardAbout.AnimY = Ease.OutBack(Ease.Clamp01((pt - 0.10f) / 0.7f));
            if (_cardSettings != null && _pageIndex == 4) _cardSettings.AnimY = Ease.OutBack(Ease.Clamp01((pt - 0.10f) / 0.7f));
            if (_btnKill != null) _btnKill.UpdateAnim(t);
            if (_btnRefresh != null) _btnRefresh.UpdateAnim(t);
            if (_btnBg != null) _btnBg.UpdateAnim(t);
            if (_procList != null) { _procList.AnimTime = t; _procList.Invalidate(); }
            if (_logList != null) { _logList.AnimTime = t; _logList.Invalidate(); }
            if (_fixList != null) { _fixList.AnimTime = t; _fixList.Invalidate(); }
            if (_fixLog != null) { _fixLog.AnimTime = t; _fixLog.Invalidate(); }
            if (_swRestart != null) _swRestart.UpdateAnim();
            if (_swBootProgress != null) _swBootProgress.UpdateAnim();
            if (_swAutostart != null) _swAutostart.UpdateAnim();
            if (_swTopmost != null) _swTopmost.UpdateAnim();
            if (_swAnim != null) _swAnim.UpdateAnim();

            // 主窗体淡入（衔接启动动画）
            if (_fadeIn < 1f)
            {
                _fadeIn += 0.045f;
                Opacity = Math.Min(1f, _fadeIn);
            }

            // 顶部提示（toast）过期隐藏
            if (_toast != null && _toast.Visible && Environment.TickCount > _toastUntil)
                _toast.Visible = false;

            // 卡片悬停微浮 + 聚光灯（直接检测光标位置，覆盖子控件区域）
            if (_cardProcs != null && _cardLog != null)
            {
                Point mp = PointToClient(Cursor.Position);
                bool inP = _cardProcs.Bounds.Contains(mp);
                bool inL = _cardLog.Bounds.Contains(mp);
                _cardProcs.LiftTarget = inP ? 1f : 0f;
                _cardLog.LiftTarget = inL ? 1f : 0f;
                _cardProcs.Lift += (_cardProcs.LiftTarget - _cardProcs.Lift) * 0.16f;
                _cardLog.Lift += (_cardLog.LiftTarget - _cardLog.Lift) * 0.16f;
                _cardProcs.SpotOn = inP;
                _cardLog.SpotOn = inL;
                if (inP)
                {
                    _cardProcs.SpotX = (mp.X - _cardProcs.Left) / (float)_cardProcs.Width;
                    _cardProcs.SpotY = (mp.Y - _cardProcs.Top) / (float)_cardProcs.Height;
                }
                if (inL)
                {
                    _cardLog.SpotX = (mp.X - _cardLog.Left) / (float)_cardLog.Width;
                    _cardLog.SpotY = (mp.Y - _cardLog.Top) / (float)_cardLog.Height;
                }
                _cardProcs.Invalidate();
                _cardLog.Invalidate();
            }

            // 光标拖尾（React Bits TrailingCursor 效果）
            Point cm = PointToClient(Cursor.Position);
            _trail.Insert(0, new PointF(cm.X, cm.Y));
            if (_trail.Count > 14) _trail.RemoveAt(_trail.Count - 1);
            for (int i = 1; i < _trail.Count; i++)
            {
                _trail[i] = new PointF(
                    _trail[i].X + (_trail[i - 1].X - _trail[i].X) * 0.35f,
                    _trail[i].Y + (_trail[i - 1].Y - _trail[i].Y) * 0.35f);
            }

            // 清理过期涟漪
            for (int i = _ripples.Count - 1; i >= 0; i--)
                if (_animTime - _ripples[i].T > 0.7f) _ripples.RemoveAt(i);

            Invalidate();
        }

        private void LoadBgFromCfg()
        {
            string p = AppConst.GetCfg("bg", "");
            if (p.Length > 0 && File.Exists(p))
            {
                try { _bgImage = Image.FromFile(p); } catch { _bgImage = null; }
            }
        }

        private void ClearBg()
        {
            if (_bgImage != null) { _bgImage.Dispose(); _bgImage = null; }
            AppConst.SetCfg("bg", "");
            AppendLog("已清除背景图，恢复液态玻璃背景。");
            Invalidate();
        }

        private void BuildUI()
        {
            _dragRect = new Rectangle(0, 0, ClientSize.Width, 52);

            // 左侧导航栏（分区页面）
            _navBar = new NavBar();
            _navBar.Bounds = new Rectangle(0, 0, 150, ClientSize.Height);
            _navBar.ItemClicked += idx => SwitchPage(idx);
            Controls.Add(_navBar);

            // 标题与副标题改由 OnPaint 自绘（透明 Label 在无边框窗体会出黑块）

            _btnMin = new Button(); _btnMin.Text = "—"; _btnMin.Bounds = new Rectangle(ClientSize.Width - 82, 10, 34, 30);
            _btnClose = new Button(); _btnClose.Text = "✕"; _btnClose.Bounds = new Rectangle(ClientSize.Width - 44, 10, 34, 30);
            foreach (Button b in new Button[] { _btnMin, _btnClose })
            {
                b.FlatStyle = FlatStyle.Flat;
                b.FlatAppearance.BorderSize = 0;
                b.FlatAppearance.MouseOverBackColor = Color.FromArgb(70, 120, 170, 220);
                b.FlatAppearance.MouseDownBackColor = Color.FromArgb(110, 120, 170, 220);
                b.BackColor = Color.FromArgb(233, 239, 247);
                b.ForeColor = AppConst.TextSub;
                b.Font = new Font("Microsoft YaHei UI", 10f, FontStyle.Regular, GraphicsUnit.Point);
                b.Cursor = Cursors.Hand;
                b.TabStop = false;
            }
            _btnClose.FlatAppearance.MouseOverBackColor = Color.FromArgb(228, 96, 96);
            _btnClose.FlatAppearance.MouseDownBackColor = Color.FromArgb(200, 80, 80);
            _btnMin.Click += (s, e) => WindowState = FormWindowState.Minimized;
            _btnClose.Click += (s, e) => Close();

            // 右上角：专属卡持有者欢迎语（卡密带 NAME: 时激活后显示）
            _lblOwner = new Label();
            _lblOwner.TextAlign = ContentAlignment.MiddleRight;
            _lblOwner.ForeColor = Color.FromArgb(47, 109, 214);
            _lblOwner.Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Bold, GraphicsUnit.Point);
            _lblOwner.BackColor = Color.FromArgb(233, 239, 247);
            _lblOwner.Cursor = Cursors.Default;
            RefreshOwner();
            Controls.Add(_lblOwner);

            // 左侧卡片：进程列表（页面1）
            _cardProcs = new GlassPanel();
            _cardProcs.Bounds = new Rectangle(174, 62, 312, 468);

            Label h1 = new Label();
            h1.Text = "目标进程 · 6 项";
            h1.Font = new Font("Microsoft YaHei UI", 10.5f, FontStyle.Bold, GraphicsUnit.Point);
            h1.ForeColor = AppConst.TextDark;
            h1.BackColor = Color.FromArgb(252, 253, 255);
            h1.Bounds = new Rectangle(20, 16, 220, 24);
            _cardProcs.Controls.Add(h1);

            _procList = new ProcList();
            _procList.Procs = AppConst.KillList;
            _procList.Disp = AppConst.KillNames;
            _running = new bool[AppConst.KillList.Length];
            _procList.Running = _running;
            _procList.Bounds = new Rectangle(14, 50, _cardProcs.Width - 28, 404);
            _cardProcs.Controls.Add(_procList);

            // 右侧卡片：日志（页面1）
            _cardLog = new GlassPanel();
            _cardLog.Bounds = new Rectangle(498, 62, ClientSize.Width - 150 - 24 - 498, 468);

            Label h2 = new Label();
            h2.Text = "运行日志";
            h2.Font = new Font("Microsoft YaHei UI", 10.5f, FontStyle.Bold, GraphicsUnit.Point);
            h2.ForeColor = AppConst.TextDark;
            h2.BackColor = Color.FromArgb(252, 253, 255);
            h2.Bounds = new Rectangle(20, 16, 160, 24);
            _cardLog.Controls.Add(h2);

            _logList = new LogList();
            _logList.Bounds = new Rectangle(16, 48, _cardLog.Width - 32, _cardLog.Height - 64);
            _cardLog.Controls.Add(_logList);

            // 底部按钮（页面1）
            _btnKill = new GlassButton();
            _btnKill.Primary = true;
            _btnKill.Text = "一键清理";
            _btnKill.StartDelay = 0.32f;
            _btnKill.Bounds = new Rectangle(ClientSize.Width - 24 - 110 - 10 - 124 - 10 - 120 - 10 - 132, 548, 132, 44);
            _btnKill.Click += (s, e) => DoKill();

            _btnRefresh = new GlassButton();
            _btnRefresh.Text = "刷新状态";
            _btnRefresh.StartDelay = 0.40f;
            _btnRefresh.Bounds = new Rectangle(ClientSize.Width - 24 - 110 - 10 - 124 - 10 - 120, 548, 120, 44);
            _btnRefresh.Click += (s, e) => RefreshProcs();

            _btnBg = new GlassButton();
            _btnBg.Text = "选择背景图";
            _btnBg.StartDelay = 0.48f;
            _btnBg.Bounds = new Rectangle(ClientSize.Width - 24 - 124, 548, 124, 44);
            _btnBg.Click += (s, e) => ChooseBg();

            // 清除背景图：恢复液态玻璃默认背景
            _btnClearBg = new GlassButton();
            _btnClearBg.Text = "清除背景图";
            _btnClearBg.StartDelay = 0.56f;
            _btnClearBg.Bounds = new Rectangle(ClientSize.Width - 24 - 124 - 10 - 110, 548, 110, 44);
            _btnClearBg.Click += (s, e) => ClearBg();

            // 页面2：恢复硬盘 & 解除管理限制
            _cardFix = new GlassPanel();
            _cardFix.Bounds = new Rectangle(174, 62, ClientSize.Width - 150 - 24 - 174, 468);
            Label h3 = new Label();
            h3.Text = "恢复硬盘 & 解除管理限制 · 6 步";
            h3.Font = new Font("Microsoft YaHei UI", 10.5f, FontStyle.Bold, GraphicsUnit.Point);
            h3.ForeColor = AppConst.TextDark;
            h3.BackColor = Color.FromArgb(252, 253, 255);
            h3.Bounds = new Rectangle(20, 16, 300, 24);
            _cardFix.Controls.Add(h3);

            _fixList = new FixList();
            _fixList.Names = AppConst.FixNames;
            _fixList.Desc = AppConst.FixDesc;
            _fixStates = new int[AppConst.FixNames.Length];
            _fixList.State = _fixStates;
            _fixList.Bounds = new Rectangle(14, 50, 540, 372);
            _cardFix.Controls.Add(_fixList);

            Label h4 = new Label();
            h4.Text = "执行日志";
            h4.Font = new Font("Microsoft YaHei UI", 10.5f, FontStyle.Bold, GraphicsUnit.Point);
            h4.ForeColor = AppConst.TextDark;
            h4.BackColor = Color.FromArgb(252, 253, 255);
            h4.Bounds = new Rectangle(570, 16, 160, 24);
            _cardFix.Controls.Add(h4);

            _fixLog = new LogList();
            _fixLog.Bounds = new Rectangle(568, 50, _cardFix.Width - 582, 372);
            _cardFix.Controls.Add(_fixLog);

            // iOS 26 药丸开关：是否在修复完成后重启资源管理器
            _swRestart = new PillSwitch();
            _swRestart.Text = "修复完成后重启资源管理器";
            _swRestart.Checked = true;
            _swRestart.Bounds = new Rectangle(14, 432, 330, 36);
            _swRestart.Changed += on => { _restartExplorer = on; };
            _cardFix.Controls.Add(_swRestart);

            _btnFix = new GlassButton();
            _btnFix.Primary = true;
            _btnFix.Text = "一键修复";
            _btnFix.StartDelay = 0.32f;
            _btnFix.Bounds = new Rectangle(ClientSize.Width - 24 - 124 - 10 - 120, 548, 254, 44);
            _btnFix.Click += (s, e) => RunFix();

            // 修复取消按钮（执行中可随时停止）
            _btnCancelFix = new GlassButton();
            _btnCancelFix.Text = "取消修复";
            _btnCancelFix.StartDelay = 0.40f;
            _btnCancelFix.Bounds = new Rectangle(ClientSize.Width - 24 - 254 - 10 - 104, 548, 104, 44);
            _btnCancelFix.Click += (s, e) =>
            {
                _fixCancel = true;
                _btnCancelFix.Enabled = false;
                _btnCancelFix.Text = "取消中…";
            };

            BuildSettingsPage();
            BuildUpdatePage();
            BuildAboutPage();

            Controls.Add(_cardProcs);
            Controls.Add(_cardLog);
            Controls.Add(_btnKill);
            Controls.Add(_btnRefresh);
            Controls.Add(_btnBg);
            Controls.Add(_btnClearBg);
            Controls.Add(_cardFix);
            Controls.Add(_btnFix);
            Controls.Add(_btnCancelFix);
            Controls.Add(_cardSettings);
            Controls.Add(_cardUpdate);
            Controls.Add(_cardAbout);
            Controls.Add(_btnMin);
            Controls.Add(_btnClose);

            _cardFix.Visible = false;
            _btnFix.Visible = false;
            _btnCancelFix.Visible = false;
            _cardSettings.Visible = false;
            _cardUpdate.Visible = false;
            _cardAbout.Visible = false;

            AppendLog("=== 云电脑守护清理 已启动 ===");
            AppendLog("黑名单：" + string.Join(" / ", AppConst.KillList));
            AppendLog("提示：一键清理仅结束上述 6 个平台进程，不会误伤系统进程。");
        }

        // ================= 设置页（页面3）：动画模式 / 进度条 / 自启 / 置顶 / 动效 + 保存 =================
        private void BuildSettingsPage()
        {
            _cardSettings = new GlassPanel();
            _cardSettings.Bounds = new Rectangle(174, 62, ClientSize.Width - 150 - 24 - 174, 468);

            Label hs = new Label();
            hs.Text = "设置 · 动画与外观";
            hs.Font = new Font("Microsoft YaHei UI", 10.5f, FontStyle.Bold, GraphicsUnit.Point);
            hs.ForeColor = AppConst.TextDark;
            hs.BackColor = Color.FromArgb(252, 253, 255);
            hs.Bounds = new Rectangle(20, 16, 260, 24);
            _cardSettings.Controls.Add(hs);

            // 行1：启动动画模式（双动画切换）
            Label l1 = new Label();
            l1.Text = "启动动画：";
            l1.Font = new Font("Microsoft YaHei UI", 9.5f, FontStyle.Regular, GraphicsUnit.Point);
            l1.ForeColor = AppConst.TextDark;
            l1.BackColor = Color.FromArgb(252, 253, 255);
            l1.Bounds = new Rectangle(20, 62, 90, 28);
            _cardSettings.Controls.Add(l1);

            _btnBoot550 = new GlassButton();
            _btnBoot550.Text = "550C 动画";
            _btnBoot550.Bounds = new Rectangle(120, 56, 130, 36);
            _btnBoot550.Click += (s, e) => SetBootMode("550c");
            _cardSettings.Controls.Add(_btnBoot550);

            _btnBootVideo = new GlassButton();
            _btnBootVideo.Text = "视频动画";
            _btnBootVideo.Bounds = new Rectangle(260, 56, 130, 36);
            _btnBootVideo.Click += (s, e) => SetBootMode("video");
            _cardSettings.Controls.Add(_btnBootVideo);

            // 行2：启动动画进度条
            _swBootProgress = new PillSwitch();
            _swBootProgress.Text = "启动动画显示进度条";
            _swBootProgress.Bounds = new Rectangle(20, 104, 300, 36);
            _cardSettings.Controls.Add(_swBootProgress);

            // 行3：开机自启
            _swAutostart = new PillSwitch();
            _swAutostart.Text = "开机自动启动";
            _swAutostart.Bounds = new Rectangle(20, 150, 300, 36);
            _cardSettings.Controls.Add(_swAutostart);

            // 行4：窗口置顶
            _swTopmost = new PillSwitch();
            _swTopmost.Text = "窗口置顶显示";
            _swTopmost.Bounds = new Rectangle(20, 196, 300, 36);
            _cardSettings.Controls.Add(_swTopmost);

            // 行5：界面动效
            _swAnim = new PillSwitch();
            _swAnim.Text = "启用界面动效";
            _swAnim.Bounds = new Rectangle(20, 242, 300, 36);
            _cardSettings.Controls.Add(_swAnim);

            // 提示文字
            Label tip = new Label();
            tip.Text = "视频动画需要 exe 同目录的 boot.mp4（或默认下载位置的视频）。\n进度条、自启、置顶、动效均点击「保存设置」后生效。";
            tip.Font = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Regular, GraphicsUnit.Point);
            tip.ForeColor = AppConst.TextSub;
            tip.BackColor = Color.FromArgb(252, 253, 255);
            tip.Bounds = new Rectangle(20, 292, _cardSettings.Width - 40, 60);
            _cardSettings.Controls.Add(tip);

            // 保存设置
            _btnSaveSettings = new GlassButton();
            _btnSaveSettings.Primary = true;
            _btnSaveSettings.Text = "保存设置";
            _btnSaveSettings.Bounds = new Rectangle(20, 400, 160, 44);
            _btnSaveSettings.Click += (s, e) => SaveSettings();
            _cardSettings.Controls.Add(_btnSaveSettings);

            // 从配置恢复初始状态
            _bootMode = AppConst.GetCfg("boot_anim", "550c");
            _swBootProgress.Checked = AppConst.GetCfg("boot_progress", "0") == "1";
            _swAutostart.Checked = AppConst.GetCfg("autostart", "0") == "1";
            _swTopmost.Checked = AppConst.GetCfg("topmost", "0") == "1";
            _swAnim.Checked = AppConst.GetCfg("anim", "1") != "0";
            _animEnabled = _swAnim.Checked;
            TopMost = _swTopmost.Checked;
            SetBootMode(_bootMode);
            AppConst.AnimEnabled = _animEnabled;
        }

        private void SetBootMode(string m)
        {
            _bootMode = m;
            if (_btnBoot550 != null) { _btnBoot550.Primary = (m == "550c"); _btnBoot550.Invalidate(); }
            if (_btnBootVideo != null) { _btnBootVideo.Primary = (m == "video"); _btnBootVideo.Invalidate(); }
        }

        private void RefreshOwner()
        {
            if (_lblOwner == null) return;
            string owner = AppConst.GetCfg("owner", "").Trim();
            if (owner.Length > 0)
            {
                string expire = AppConst.GetCfg("activated_expire", "").Trim();
                string tail = "";
                if (expire.Length > 0)
                {
                    try
                    {
                        DateTime exp;
                        if (DateTime.TryParseExact(expire, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out exp))
                        {
                            TimeSpan left = exp - DateTime.Now;
                            if (left.TotalSeconds >= 0)
                            {
                                tail = " · 剩余 " + FormatDur(left);
                                _expireWarning = false;
                            }
                            else
                            {
                                tail = " · 已过期 " + FormatDur(-left);
                                _lblOwner.ForeColor = Color.FromArgb(205, 62, 62);
                                // 到期实时触发重新激活（只弹一次，防刷屏）
                                if (!_expireWarning && AppConst.GetCfg("activated", "0") == "1")
                                {
                                    _expireWarning = true;
                                    try
                                    {
                                        BeginInvoke((MethodInvoker)delegate ()
                                        {
                                            AppConst.Log("卡密已到期，强制重新激活");
                                            using (ActivateForm af = new ActivateForm())
                                            {
                                                if (af.ShowDialog() != DialogResult.OK) Close();
                                                else
                                                {
                                                    _expireWarning = false;
                                                    _lblOwner.ForeColor = Color.FromArgb(47, 62, 84);
                                                    RefreshOwner();
                                                }
                                            }
                                        });
                                    }
                                    catch { }
                                }
                            }
                        }
                    }
                    catch { }
                }
                _lblOwner.Text = "欢迎，" + owner + tail;
                _lblOwner.Visible = true;
            }
            else
            {
                _lblOwner.Text = "";
                _lblOwner.Visible = false;
            }
            // 右上角：欢迎语 与 最小化按钮 之间
            _lblOwner.Bounds = new Rectangle(ClientSize.Width - 322, 12, 224, 26);
        }

        // 时长格式：精确到秒。1天2小时 → "1天 02:03:04"；58秒 → "58 秒"
        static string FormatDur(TimeSpan t)
        {
            if (t <= TimeSpan.Zero) return "0 秒";
            int d = (int)t.TotalDays;
            int h = t.Hours, m = t.Minutes, s = t.Seconds;
            if (d > 0) return d + "天 " + h.ToString("00") + ":" + m.ToString("00") + ":" + s.ToString("00");
            if (h > 0) return h + "小时 " + m.ToString("00") + "分 " + s.ToString("00") + "秒";
            if (m > 0) return m + "分 " + s.ToString("00") + "秒";
            return s + " 秒";
        }

        // ================= 更新日志（页面3） =================
        private void BuildUpdatePage()
        {
            _cardUpdate = new GlassPanel();
            _cardUpdate.Bounds = new Rectangle(174, 62, ClientSize.Width - 150 - 24 - 174, 468);

            Label hu = new Label();
            hu.Text = "更新日志";
            hu.Font = new Font("Microsoft YaHei UI", 10.5f, FontStyle.Bold, GraphicsUnit.Point);
            hu.ForeColor = AppConst.TextDark;
            hu.BackColor = Color.FromArgb(252, 253, 255);
            hu.Bounds = new Rectangle(20, 16, 220, 24);
            _cardUpdate.Controls.Add(hu);

            // 版本条目（最新在上）
            string[] ver = {
                "v9 · 2026-10-01",
                "视频动画黑边彻底修复（按视频原生比例 + 悬浮进度条不占高度）",
                "进度条升级为液态玻璃风格（模糊背景+渐变+发光+流动光泽）",
                "新增「更新日志」「关于」页面",
                "",
                "v8 · 2026-10-01",
                "视频动画稳定：时长/尺寸文件头解析、播完淡出接主窗体淡入",
                "设置页开关修复、保存设置 Toast 提示",
                "",
                "v7 · 2026-10-01",
                "新增「恢复硬盘」页（6 步修复：清 NoDrives/策略键/权限/禁用隐藏/刷新）",
                "修复可取消、开机自启/置顶/动效开关",
                "",
                "v6 · 2026-10-01",
                "三页导航分区、真·液态玻璃背景、iOS 药丸开关",
                "借鉴开源项目「窗影归舟」与 React Bits 动效",
                "",
                "v5 · 2026-10-01",
                "550C 开机动画 + 主界面（进程清理/运行日志/一键清理）",
                "6 项平台守护进程一键终止，保护 13 项系统进程",
            };
            int yy = 54;
            foreach (string line in ver)
            {
                if (line.Length == 0) { yy += 8; continue; }
                bool isTitle = line.StartsWith("v");
                Label l = new Label();
                l.Text = line;
                l.AutoSize = true;
                l.Font = new Font("Microsoft YaHei UI", (isTitle ? 9.5f : 8.5f), isTitle ? FontStyle.Bold : FontStyle.Regular, GraphicsUnit.Point);
                l.ForeColor = isTitle ? Color.FromArgb(47, 109, 214) : AppConst.TextSub;
                l.BackColor = Color.FromArgb(252, 253, 255);
                l.Location = new Point(24, yy);
                _cardUpdate.Controls.Add(l);
                yy += isTitle ? 20 : 18;
            }
        }

        // ================= 关于（页面4） =================
        private void BuildAboutPage()
        {
            _cardAbout = new GlassPanel();
            _cardAbout.Bounds = new Rectangle(174, 62, ClientSize.Width - 150 - 24 - 174, 468);

            Label ha = new Label();
            ha.Text = "关于";
            ha.Font = new Font("Microsoft YaHei UI", 10.5f, FontStyle.Bold, GraphicsUnit.Point);
            ha.ForeColor = AppConst.TextDark;
            ha.BackColor = Color.FromArgb(252, 253, 255);
            ha.Bounds = new Rectangle(20, 16, 220, 24);
            _cardAbout.Controls.Add(ha);

            // Logo 区块：圆角浅色块 + 名称
            GlassPanel logo = new GlassPanel();
            logo.Bounds = new Rectangle(24, 56, _cardAbout.Width - 48, 86);
            Label nm = new Label();
            nm.Text = "云电脑守护清理";
            nm.Font = new Font("Microsoft YaHei UI", 15f, FontStyle.Bold, GraphicsUnit.Point);
            nm.ForeColor = AppConst.TextDark;
            nm.BackColor = Color.FromArgb(246, 249, 253);
            nm.Bounds = new Rectangle(24, 18, 220, 32);
            logo.Controls.Add(nm);
            Label en = new Label();
            en.Text = "OKK CLOUD GUARDIAN · 550C";
            en.Font = new Font("Consolas", 8.5f, FontStyle.Regular, GraphicsUnit.Point);
            en.ForeColor = AppConst.TextSub;
            en.BackColor = Color.FromArgb(246, 249, 253);
            en.Bounds = new Rectangle(24, 52, 280, 18);
            logo.Controls.Add(en);
            _cardAbout.Controls.Add(logo);

            string[] info = {
                "版本　　v9.0",
                "作者　　默白（もくはく）",
                "平台　　海马云游戏云电脑宿主机",
                "功能　　一键清理 6 项平台守护进程（不误伤系统进程）",
                "　　　　恢复隐藏硬盘 / 解除管理限制（6 步）",
                "　　　　双启动动画：550C 开机动画 / 本地视频动画",
                "界面　　液态玻璃 · 开源风格动效（React Bits / 窗影归舟）",
                "鸣谢　　550C 开机动画（GitHub yannicksong0106 · MIT）",
                "　　　　窗影归舟开源项目（液态玻璃 / 药丸开关）",
            };
            int yy = 158;
            foreach (string line in info)
            {
                Label l = new Label();
                l.Text = line;
                l.AutoSize = true;
                l.Font = new Font("Microsoft YaHei UI", 8.8f, FontStyle.Regular, GraphicsUnit.Point);
                l.ForeColor = AppConst.TextDark;
                l.BackColor = Color.FromArgb(252, 253, 255);
                l.Location = new Point(28, yy);
                _cardAbout.Controls.Add(l);
                yy += 24;
            }
        }

        private void SaveSettings()
        {
            AppConst.SetCfg("boot_anim", _bootMode);
            AppConst.SetCfg("boot_progress", _swBootProgress.Checked ? "1" : "0");
            AppConst.SetCfg("autostart", _swAutostart.Checked ? "1" : "0");
            AppConst.SetCfg("topmost", _swTopmost.Checked ? "1" : "0");
            AppConst.SetCfg("anim", _swAnim.Checked ? "1" : "0");
            TopMost = _swTopmost.Checked;
            _animEnabled = _swAnim.Checked;
            AppConst.AnimEnabled = _animEnabled;
            SetAutostart(_swAutostart.Checked);
            AppendLog("设置已保存：动画=" + _bootMode + " 进度条=" + (_swBootProgress.Checked ? "开" : "关")
                + " 自启=" + (_swAutostart.Checked ? "开" : "关") + " 置顶=" + (_swTopmost.Checked ? "开" : "关")
                + " 动效=" + (_swAnim.Checked ? "开" : "关"));
            ShowToast("✔ 设置已保存，下次启动生效");
        }

        private void SetAutostart(bool on)
        {
            try
            {
                using (RegistryKey rk = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run"))
                {
                    if (on) rk.SetValue("OKKGuardian", "\"" + Application.ExecutablePath + "\"");
                    else rk.DeleteValue("OKKGuardian", false);
                }
            }
            catch { }
        }

        private void ApplyRegion()
        {
            // 不使用 Region 圆角裁剪：无边框矩形窗体，杜绝边缘锯齿/黑边
        }

        private void RefreshProcs()
        {
            for (int i = 0; i < _running.Length; i++)
            {
                Process[] ps = Process.GetProcessesByName(AppConst.KillList[i]);
                _running[i] = ps != null && ps.Length > 0;
                foreach (Process p in ps) p.Dispose();
            }
            if (_procList != null) _procList.Invalidate();
        }

        private void DoKill()
        {
            _btnKill.Enabled = false;
            _btnKill.Text = "清理中…";
            AppendLog(">>> 开始清理 " + DateTime.Now.ToString("HH:mm:ss"));
            int killed = 0;
            for (int i = 0; i < AppConst.KillList.Length; i++)
            {
                string name = AppConst.KillList[i];
                if (Array.IndexOf(AppConst.ProtectList, name) >= 0) continue;
                try
                {
                    Process[] ps = Process.GetProcessesByName(name);
                    foreach (Process p in ps)
                    {
                        try
                        {
                            string line = "KILL  " + name + ".exe (PID " + p.Id + ")";
                            p.Kill();
                            try { p.WaitForExit(2000); } catch { }
                            killed++;
                            AppendLog(line);
                            AppConst.Log(line);
                        }
                        catch (Exception ex)
                        {
                            string line = "FAIL  " + name + ".exe (PID " + p.Id + ") : " + ex.Message;
                            AppendLog(line);
                            AppConst.Log(line);
                        }
                        finally { try { p.Dispose(); } catch { } }
                    }
                }
                catch (Exception ex)
                {
                    AppendLog("ERR   " + name + " : " + ex.Message);
                    AppConst.Log("ERR   " + name + " : " + ex.Message);
                }
            }
            string sum = "SUMMARY killed=" + killed + " at " + DateTime.Now.ToString("HH:mm:ss");
            AppendLog(sum);
            AppConst.Log(sum);
            _lastKill = DateTime.Now.ToString("HH:mm:ss") + " · 清理 " + killed + " 个";
            _btnKill.Text = "一键清理";
            _btnKill.Enabled = true;
            RefreshProcs();
            if (killed == 0) AppendLog("未发现运行中的目标进程，环境干净。");
            else AppendLog("清理完成。");
        }

        private void SwitchPage(int idx)
        {
            if (idx == _pageIndex) return;
            _pageIndex = idx;
            _pageSwitchTime = _animTime;
            bool p0 = idx == 0, p1 = idx == 1, p2 = idx == 2, p3 = idx == 3, p4 = idx == 4;
            _cardProcs.Visible = p0;
            _cardLog.Visible = p0;
            _btnKill.Visible = p0;
            _btnRefresh.Visible = p0;
            _btnBg.Visible = p0;
            _btnClearBg.Visible = p0;
            _cardFix.Visible = p1;
            _btnFix.Visible = p1;
            _btnCancelFix.Visible = p1;
            _cardUpdate.Visible = p2;
            _cardAbout.Visible = p3;
            _cardSettings.Visible = p4;
            if (p0)
            {
                _cardProcs.AnimY = 0f; _cardLog.AnimY = 0f;
            }
            else if (p1)
            {
                _cardFix.AnimY = 0f;
                _fixList.AnimTime = 0f;
                _fixLog.AnimTime = 0f;
            }
            else if (p2)
            {
                _cardUpdate.AnimY = 0f;
            }
            else if (p3)
            {
                _cardAbout.AnimY = 0f;
            }
            else
            {
                _cardSettings.AnimY = 0f;
            }
            Invalidate();
        }

        // ================= 恢复硬盘 & 解除管理限制（6 步） =================

        private void FixLogAppend(string line)
        {
            Color c = AppConst.TextDark;
            if (line.StartsWith(">>>")) c = Color.FromArgb(47, 109, 214);
            else if (line.StartsWith("OK")) c = Color.FromArgb(52, 148, 96);
            else if (line.StartsWith("FAIL") || line.StartsWith("ERR")) c = Color.FromArgb(205, 62, 62);
            _fixLog.Add(DateTime.Now.ToString("HH:mm:ss"), line, c);
        }

        private void RunFix()
        {
            if (_fixRunning) return;
            if (!IsAdmin())
            {
                MessageBox.Show(this, "恢复硬盘功能需要管理员权限。\n请右键本程序 → 以管理员身份运行。", "云电脑守护清理", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            _fixRunning = true;
            _fixCancel = false;
            _btnFix.Enabled = false;
            _btnFix.Text = "修复中…";
            _btnCancelFix.Visible = true;
            _btnCancelFix.Enabled = true;
            _btnCancelFix.Text = "取消修复";
            for (int i = 0; i < _fixStates.Length; i++) _fixStates[i] = 0;
            _fixList.Invalidate();
            FixLogAppend(">>> 开始修复（共 6 步）");

            System.Threading.Thread th = new System.Threading.Thread(() =>
            {
                try
                {
                    RunFixStep(0, FixStep1);
                    RunFixStep(1, FixStep2);
                    RunFixStep(2, FixStep3);
                    RunFixStep(3, FixStep4);
                    RunFixStep(4, FixStep5);
                    RunFixStep(5, FixStep6);
                }
                catch (Exception ex)
                {
                    try { BeginInvoke(new Action(() => FixLogAppend("ERR 修复中断: " + ex.Message))); } catch { }
                }
                finally
                {
                    try
                    {
                        BeginInvoke(new Action(() =>
                        {
                            _fixRunning = false;
                            _btnFix.Enabled = true;
                            _btnFix.Text = "一键修复";
                            _btnCancelFix.Visible = false;
                            FixLogAppend(_fixCancel ? "修复已由用户取消。" : "全部步骤执行完毕。若盘符未立即显示，请按 F5 刷新。");
                        }));
                    }
                    catch { }
                }
            });
            th.IsBackground = true;
            th.Start();
        }

        private void RunFixStep(int i, Func<bool> step)
        {
            // 取消检查：停止后续步骤
            if (_fixCancel)
            {
                try
                {
                    BeginInvoke(new Action(() =>
                    {
                        for (int k = i; k < _fixStates.Length; k++)
                        {
                            if (_fixStates[k] == 0) _fixStates[k] = 4;
                        }
                        _fixList.Invalidate();
                        FixLogAppend("已取消：步骤 " + AppConst.FixNames[i] + " 及后续步骤跳过");
                    }));
                }
                catch { }
                return;
            }
            try { BeginInvoke(new Action(() => { _fixStates[i] = 1; _fixList.Invalidate(); FixLogAppend(">>> " + AppConst.FixNames[i] + " 开始"); })); } catch { }
            bool ok = false;
            try { ok = step(); }
            catch (Exception ex) { try { BeginInvoke(new Action(() => FixLogAppend("ERR " + ex.Message))); } catch { } }
            int s = ok ? 2 : 3;
            try { BeginInvoke(new Action(() => { _fixStates[i] = s; _fixList.Invalidate(); FixLogAppend((ok ? "OK  " : "FAIL") + " " + AppConst.FixNames[i]); })); } catch { }
            System.Threading.Thread.Sleep(120);
        }

        // 步骤1：恢复硬盘显示
        private bool FixStep1()
        {
            string gp = @"C:\Windows\System32\GroupPolicy";
            try
            {
                if (Directory.Exists(gp))
                {
                    RunHiddenCmd("powershell -NoProfile -Command \"Remove-Item -Path 'C:/Windows/System32/GroupPolicy' -Force -Recurse -ErrorAction SilentlyContinue\"");
                    FixLogAppend("组策略存储目录已清理");
                }
            }
            catch { }
            Registry.LocalMachine.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer").SetValue("NoDrives", 0, RegistryValueKind.DWord);
            Registry.CurrentUser.DeleteValue(@"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\NoDrives", false);
            Registry.CurrentUser.DeleteValue(@"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\NoViewOnDrive", false);
            CommentHideDrive();
            return true;
        }

        // 注释 run_server_scripts.py 中的 hide_drive 线程（禁用平台盘符守护写回）
        private bool CommentHideDrive()
        {
            string path = @"C:\HM-GameServer\run_server_scripts.py";
            if (!File.Exists(path)) { FixLogAppend("未找到 run_server_scripts.py，跳过平台守护禁用"); return true; }
            try
            {
                string[] lines = File.ReadAllLines(path, Encoding.UTF8);
                StringBuilder sb = new StringBuilder();
                bool changed = false;
                foreach (string raw in lines)
                {
                    string line = raw;
                    string trim = line.TrimStart();
                    bool isComment = trim.StartsWith("#");
                    if (line.IndexOf("hide_drive_thread", StringComparison.OrdinalIgnoreCase) >= 0 && !isComment)
                    {
                        sb.Append("# ").Append(line);
                        changed = true;
                    }
                    else sb.Append(line);
                    sb.Append('\n');
                }
                if (changed)
                {
                    string bak = path + ".bak_" + DateTime.Now.ToString("yyyyMMdd_HHmmss");
                    File.Copy(path, bak, true);
                    File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
                    FixLogAppend("run_server_scripts.py 的 hide_drive 线程已注释（已备份）");
                    RunHiddenCmd("powershell -NoProfile -Command \"Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'run_server_scripts' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }\"");
                }
                else FixLogAppend("hide_drive 线程已处于禁用状态");
                return true;
            }
            catch (Exception ex) { FixLogAppend("ERR 注释脚本失败: " + ex.Message); return false; }
        }

        // 步骤2：清理组策略限制
        private bool FixStep2()
        {
            Registry.CurrentUser.DeleteSubKeyTree(@"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer", false);
            Registry.CurrentUser.DeleteSubKeyTree(@"Software\Microsoft\Windows\CurrentVersion\Policies\System", false);
            Registry.CurrentUser.DeleteSubKeyTree(@"Software\Policies\Microsoft\Windows\System", false);
            Registry.CurrentUser.DeleteSubKeyTree(@"Software\Policies\Microsoft\MMC", false);
            return true;
        }

        // 步骤3：取消目录防护（icacls 授权）
        private bool FixStep3()
        {
            string[] paths = {
                @"C:\HM-GameServer", @"C:\HM-GSU-Guest", @"C:\filebeat", @"C:\games",
                @"C:\hm_temp_info", @"C:\rsync", @"C:\tools", @"C:\ver", @"C:\zabbix",
                @"M:\gameData\deploy", @"C:\run-server.bat", @"C:\c_run-server.bat",
                @"C:\run_gs_agent.py", @"C:\c_run_gs_agent.py", @"C:\firewall_version",
                @"C:\env_init.ps1", @"C:\env_init.reg", @"O:\online_game\L1" };
            foreach (string p in paths)
            {
                if (Directory.Exists(p) || File.Exists(p))
                    RunHiddenCmd("icacls \"" + p + "\" /grant Administrator:F");
            }
            return true;
        }

        // 步骤4：取消 Win 组件防护（禁用 TaskBarHider）
        private bool FixStep4()
        {
            string tb = @"C:\Windows\TaskBarHider.exe";
            string tbd = @"C:\Windows\TaskBarHider.exe.disabled";
            try
            {
                if (File.Exists(tb))
                {
                    string bak = @"C:\Windows\TaskBarHider.exe.bak_" + DateTime.Now.ToString("yyyyMMdd_HHmmss");
                    File.Copy(tb, bak, true);
                    File.Move(tb, tbd);
                    FixLogAppend("TaskBarHider.exe 已改名禁用（原文件已备份）");
                }
                else if (File.Exists(tbd)) FixLogAppend("TaskBarHider 已处于禁用状态");
            }
            catch (Exception ex) { FixLogAppend("ERR " + ex.Message); return false; }
            RunHiddenCmd("taskkill /F /IM TaskBarHider.exe");
            RunHiddenCmd("schtasks /Change /TN \"hide taskbar\" /Disable");
            return true;
        }

        // 步骤5：取消目录隐藏（显示隐藏文件）
        private bool FixStep5()
        {
            Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced").SetValue("Hidden", 1, RegistryValueKind.DWord);
            return true;
        }

        // 步骤6：应用策略并刷新
        private bool FixStep6()
        {
            RunHiddenCmd("gpupdate /force");
            if (_restartExplorer)
            {
                RunHiddenCmd("taskkill /F /IM explorer.exe");
                System.Threading.Thread.Sleep(2000);
                try { Process.Start(new ProcessStartInfo("explorer.exe") { UseShellExecute = true }); } catch { }
            }
            return true;
        }

        private static void RunHiddenCmd(string cmdline)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", "/c " + cmdline);
                psi.CreateNoWindow = true;
                psi.WindowStyle = ProcessWindowStyle.Hidden;
                psi.UseShellExecute = false;
                using (Process p = Process.Start(psi)) { if (p != null) p.WaitForExit(15000); }
            }
            catch { }
        }

        // 打开后自动解除管理限制：静默执行 6 步核心操作（无需 UI 交互）
        public void AutoUnlockLimits()
        {
            try
            {
                if (!IsAdmin()) { AppConst.Log("自动解除限制：无管理员权限，跳过（请以管理员身份运行）"); return; }
                AppConst.Log("自动解除限制：开始执行 6 步");
                FixStep1(); FixStep2(); FixStep3(); FixStep4(); FixStep5(); FixStep6();
                AppConst.Log("自动解除限制：6 步执行完毕");
            }
            catch (Exception ex) { AppConst.Log("自动解除限制失败: " + ex.Message); }
        }

        private static bool IsAdmin()
        {
            try
            {
                System.Security.Principal.WindowsIdentity id = System.Security.Principal.WindowsIdentity.GetCurrent();
                return new System.Security.Principal.WindowsPrincipal(id).IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
            }
            catch { return false; }
        }

        private void ChooseBg()
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Title = "选择背景图片";
                ofd.Filter = "图片文件|*.png;*.jpg;*.jpeg;*.bmp;*.webp|所有文件|*.*";
                if (ofd.ShowDialog(this) == DialogResult.OK)
                {
                    try
                    {
                        if (_bgImage != null) { _bgImage.Dispose(); _bgImage = null; }
                        _bgImage = Image.FromFile(ofd.FileName);
                        AppConst.SetCfg("bg", ofd.FileName);
                        AppendLog("背景图已设置：" + ofd.FileName);
                        Invalidate();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "背景图加载失败：" + ex.Message, "云电脑守护清理", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
        }

        private void AppendLog(string line)
        {
            Color c = AppConst.TextDark;
            if (line.StartsWith("KILL")) c = Color.FromArgb(37, 106, 208);
            else if (line.StartsWith("FAIL") || line.StartsWith("ERR")) c = Color.FromArgb(205, 62, 62);
            else if (line.StartsWith("SUMMARY")) c = Color.FromArgb(52, 148, 96);
            else if (line.StartsWith(">>>")) c = Color.FromArgb(47, 109, 214);
            _logList.Add(DateTime.Now.ToString("HH:mm:ss"), line, c);
        }

        // 背景：自定义图（压亮）或浅色渐变 + Aurora 流动光斑（React Bits 风格）
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Rectangle r = ClientRectangle;
            if (_bgImage != null)
            {
                float imgRatio = (float)_bgImage.Width / _bgImage.Height;
                float winRatio = (float)r.Width / r.Height;
                int sw, sh;
                if (imgRatio > winRatio) { sh = r.Height; sw = (int)(r.Height * imgRatio); }
                else { sw = r.Width; sh = (int)(r.Width / imgRatio); }
                int sx = (r.Width - sw) / 2, sy = (r.Height - sh) / 2;
                g.DrawImage(_bgImage, new Rectangle(sx, sy, sw, sh));
                using (SolidBrush lighten = new SolidBrush(Color.FromArgb(196, 240, 246, 252)))
                    g.FillRectangle(lighten, r);
                return;
            }

            // 真·液态玻璃：桌面实时模糊背景（源自 RealtimeBlurEngine：下采样 + 盒式模糊）
            if (_glassBmp != null)
            {
                g.DrawImage(_glassBmp, r);
                using (SolidBrush lighten = new SolidBrush(Color.FromArgb(172, 244, 248, 253)))
                    g.FillRectangle(lighten, r);
            }
            else
            {
                using (LinearGradientBrush lg = new LinearGradientBrush(r, Color.FromArgb(216, 228, 241), Color.FromArgb(241, 246, 252), 115f))
                    g.FillRectangle(lg, r);
            }

            g.SmoothingMode = SmoothingMode.AntiAlias;

            // 淡 Aurora + 粒子：界面动效开启时才绘制
            if (AppConst.AnimEnabled)
            {
                float t = _animTime;
                DrawAurora(g, r, r.Width * (0.62f + 0.10f * (float)Math.Sin(t * 0.31)), r.Height * (0.12f + 0.06f * (float)Math.Cos(t * 0.27)), r.Width * 0.62f, r.Height * 0.52f, Color.FromArgb(48, 125, 211, 248));
                DrawAurora(g, r, r.Width * (0.10f + 0.08f * (float)Math.Sin(t * 0.23 + 2.1)), r.Height * (0.58f + 0.07f * (float)Math.Cos(t * 0.29 + 1.2)), r.Width * 0.56f, r.Height * 0.60f, Color.FromArgb(40, 96, 165, 250));
                DrawAurora(g, r, r.Width * (0.55f + 0.09f * (float)Math.Sin(t * 0.19 + 4.2)), r.Height * (0.80f + 0.06f * (float)Math.Cos(t * 0.25 + 3.0)), r.Width * 0.60f, r.Height * 0.44f, Color.FromArgb(34, 94, 234, 212));

                const float GOLD = 0.61803398875f;
                for (int i = 0; i < 22; i++)
                {
                    float fx = (float)((i * GOLD) % 1.0);
                    float fy = (float)((i * 0.38196601) % 1.0);
                    float px = fx * r.Width + (float)Math.Sin(t * 0.32 + i * 1.7) * 16f;
                    float py = fy * r.Height + (float)Math.Cos(t * 0.24 + i * 2.3) * 12f;
                    float pa = 40f + 28f * (float)Math.Sin(t * 0.9 + i * 1.3);
                    float pr = 1.4f + 1.1f * (float)((i * 0.137f) % 1.0);
                    using (SolidBrush pb = new SolidBrush(Color.FromArgb((int)pa, 255, 255, 255)))
                        g.FillEllipse(pb, px, py, pr * 2f, pr * 2f);
                }
            }
        }

        // ================= 液态玻璃实时模糊（RealtimeBlurEngine 移植） =================

        private void CaptureGlass()
        {
            try
            {
                Rectangle scr = new Rectangle(Left, Top, Width, Height);
                if (scr.Width <= 8 || scr.Height <= 8) return;
                int sw = Math.Max(32, scr.Width / 4), sh = Math.Max(32, scr.Height / 4);
                using (Bitmap raw = new Bitmap(scr.Width, scr.Height))
                {
                    using (Graphics rg = Graphics.FromImage(raw))
                    {
                        rg.CopyFromScreen(scr.Location, Point.Empty, scr.Size);
                    }
                    Bitmap small = new Bitmap(sw, sh);
                    using (Graphics sg = Graphics.FromImage(small))
                    {
                        sg.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBilinear;
                        sg.DrawImage(raw, 0, 0, sw, sh);
                    }
                    BoxBlur(small, 2, 2);
                    if (_glassBmp != null) _glassBmp.Dispose();
                    _glassBmp = small;
                }
                _glassDirty = false;
            }
            catch { }
        }

        // 下采样图上的横纵盒式模糊（radius 次横向 + radius 次纵向，等价多次高斯近似）
        private static void BoxBlur(Bitmap bmp, int radius, int passes)
        {
            int w = bmp.Width, h = bmp.Height;
            Rectangle rr = new Rectangle(0, 0, w, h);
            System.Drawing.Imaging.BitmapData bd = bmp.LockBits(rr, System.Drawing.Imaging.ImageLockMode.ReadWrite, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
            int stride = bd.Stride;
            byte[] src = new byte[stride * h];
            byte[] dst = new byte[stride * h];
            System.Runtime.InteropServices.Marshal.Copy(bd.Scan0, src, 0, src.Length);
            for (int pass = 0; pass < passes; pass++)
            {
                // 横向
                for (int y = 0; y < h; y++)
                {
                    int row = y * stride;
                    for (int x = 0; x < w; x++)
                    {
                        int i = row + x * 4;
                        int b0 = 0, g0 = 0, r0 = 0, cnt = 0;
                        for (int dx = -radius; dx <= radius; dx++)
                        {
                            int xx = x + dx;
                            if (xx < 0 || xx >= w) continue;
                            int j = row + xx * 4;
                            b0 += src[j]; g0 += src[j + 1]; r0 += src[j + 2]; cnt++;
                        }
                        dst[i] = (byte)(b0 / cnt); dst[i + 1] = (byte)(g0 / cnt); dst[i + 2] = (byte)(r0 / cnt);
                        dst[i + 3] = src[i + 3];
                    }
                }
                Array.Copy(dst, src, src.Length);
                // 纵向
                for (int y = 0; y < h; y++)
                {
                    int row = y * stride;
                    for (int x = 0; x < w; x++)
                    {
                        int i = row + x * 4;
                        int b0 = 0, g0 = 0, r0 = 0, cnt = 0;
                        for (int dy = -radius; dy <= radius; dy++)
                        {
                            int yy = y + dy;
                            if (yy < 0 || yy >= h) continue;
                            int j = yy * stride + x * 4;
                            b0 += src[j]; g0 += src[j + 1]; r0 += src[j + 2]; cnt++;
                        }
                        dst[i] = (byte)(b0 / cnt); dst[i + 1] = (byte)(g0 / cnt); dst[i + 2] = (byte)(r0 / cnt);
                        dst[i + 3] = src[i + 3];
                    }
                }
                Array.Copy(dst, src, src.Length);
            }
            System.Runtime.InteropServices.Marshal.Copy(src, 0, bd.Scan0, src.Length);
            bmp.UnlockBits(bd);
        }

        private void DrawAurora(Graphics g, Rectangle r, float cx, float cy, float w, float h, Color c)
        {
            float x0 = cx - w / 2f, y0 = cy - h / 2f;
            RectangleF rf = new RectangleF(x0, y0, w, h);
            using (System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath())
            {
                gp.AddEllipse(rf);
                using (System.Drawing.Drawing2D.PathGradientBrush pgb = new System.Drawing.Drawing2D.PathGradientBrush(gp))
                {
                    pgb.CenterColor = c;
                    pgb.SurroundColors = new Color[] { Color.FromArgb(0, c.R, c.G, c.B) };
                    g.FillPath(pgb, gp);
                }
            }
        }

        // 标题/副标题/底部状态/拖尾/涟漪：由窗体自绘（透明 Label 会出黑块，故全部移除）
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            // 渐变流动标题（React Bits GradientText 效果）
            float titleAngle = AppConst.AnimEnabled ? (18f + 10f * (float)Math.Sin(_animTime * 0.7)) : 18f;
            using (Font f = new Font("Microsoft YaHei UI", 12f, FontStyle.Bold, GraphicsUnit.Point))
            using (System.Drawing.Drawing2D.LinearGradientBrush tg = new System.Drawing.Drawing2D.LinearGradientBrush(
                new Rectangle(170, 12, 240, 30),
                Color.FromArgb(47, 109, 214),
                Color.FromArgb(46, 182, 222),
                titleAngle))
                g.DrawString("云电脑守护清理", f, tg, 170, 12);
            using (Font f2 = new Font("Consolas", 8f, FontStyle.Regular, GraphicsUnit.Point))
            using (SolidBrush b2 = new SolidBrush(AppConst.TextSub))
                g.DrawString("OKK CLOUD GUARDIAN · 550C", f2, b2, 172, 38);

            // 标题光泽扫过（丝滑生动）
            if (AppConst.AnimEnabled)
            {
                float shPos = (float)((_animTime + 0.7) % 4.2) / 4.2f;
                int sx = 160 + (int)(shPos * 320f) - 80;
                Rectangle shineR = new Rectangle(sx, 8, 80, 40);
                using (System.Drawing.Drawing2D.LinearGradientBrush sh = new System.Drawing.Drawing2D.LinearGradientBrush(
                    shineR,
                    Color.FromArgb(0, 255, 255, 255),
                    Color.FromArgb(200, 255, 255, 255),
                    System.Drawing.Drawing2D.LinearGradientMode.Horizontal))
                    g.FillRectangle(sh, shineR);
            }

            // 光标拖尾光点（TrailingCursor）
            if (AppConst.AnimEnabled)
            {
                for (int i = _trail.Count - 1; i >= 1; i--)
                {
                    float k = (float)(_trail.Count - 1 - i) / (_trail.Count - 1);
                    float alpha = 85f * (1f - k);
                    float rr = 1.2f + 3.4f * (1f - k);
                    using (SolidBrush tb = new SolidBrush(Color.FromArgb((int)alpha, 138, 190, 255)))
                        g.FillEllipse(tb, _trail[i].X - rr, _trail[i].Y - rr, rr * 2f, rr * 2f);
                }

                // 点击涟漪（Ripple）
                foreach (Ripple rp in _ripples)
                {
                    float age = _animTime - rp.T;
                    if (age < 0f || age > 0.7f) continue;
                    float k = age / 0.7f;
                    float rad = 10f + k * 170f;
                    int a = (int)(140f * (1f - k));
                    using (Pen rpen = new Pen(Color.FromArgb(a, 120, 175, 255), 2f))
                        g.DrawEllipse(rpen, rp.X - rad, rp.Y - rad, rad * 2f, rad * 2f);
                    using (Pen rpen2 = new Pen(Color.FromArgb((int)(a * 0.5f), 160, 205, 255), 1f))
                        g.DrawEllipse(rpen2, rp.X - rad * 0.6f, rp.Y - rad * 0.6f, rad * 1.2f, rad * 1.2f);
                }
            }

            // 底部状态
            string st = "上次清理：" + _lastKill + "       时间：" + DateTime.Now.ToString("HH:mm:ss");
            using (Font f3 = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Regular, GraphicsUnit.Point))
            using (SolidBrush b3 = new SolidBrush(AppConst.TextSub))
                g.DrawString(st, f3, b3, 174, 556);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            if (_cardProcs == null || _cardLog == null) return;
            _dragRect = new Rectangle(0, 0, ClientSize.Width, 52);
            _btnMin.Location = new Point(ClientSize.Width - 82, 10);
            _btnClose.Location = new Point(ClientSize.Width - 44, 10);
            if (_navBar != null) _navBar.Bounds = new Rectangle(0, 0, 150, ClientSize.Height);
            _cardLog.Bounds = new Rectangle(498, 62, ClientSize.Width - 150 - 24 - 498, 468);
            _logList.Bounds = new Rectangle(16, 48, _cardLog.Width - 32, _cardLog.Height - 64);
            if (_cardFix != null)
            {
                _cardFix.Bounds = new Rectangle(174, 62, ClientSize.Width - 150 - 24 - 174, 468);
                _fixLog.Bounds = new Rectangle(568, 50, _cardFix.Width - 582, 372);
                if (_swRestart != null) _swRestart.Bounds = new Rectangle(14, 432, 330, 36);
            }
            _btnKill.Location = new Point(ClientSize.Width - 24 - 110 - 10 - 124 - 10 - 120 - 10 - 132, 548);
            _btnRefresh.Location = new Point(ClientSize.Width - 24 - 110 - 10 - 124 - 10 - 120, 548);
            _btnBg.Location = new Point(ClientSize.Width - 24 - 124, 548);
            if (_btnClearBg != null) _btnClearBg.Location = new Point(ClientSize.Width - 24 - 124 - 10 - 110, 548);
            if (_btnFix != null) _btnFix.Location = new Point(ClientSize.Width - 24 - 254, 548);
            if (_btnCancelFix != null) _btnCancelFix.Location = new Point(ClientSize.Width - 24 - 254 - 10 - 104, 548);
            if (_cardSettings != null) _cardSettings.Bounds = new Rectangle(174, 62, ClientSize.Width - 150 - 24 - 174, 468);
            Invalidate();
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x84) // WM_NCHITTEST
            {
                Point pt = PointToClient(Cursor.Position);
                if (_dragRect.Contains(pt)) { m.Result = (IntPtr)2; return; }
            }
            base.WndProc(ref m);
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            if (_clockTimer != null) _clockTimer.Stop();
            if (_animTimer != null) _animTimer.Stop();
            if (_blurTimer != null) _blurTimer.Stop();
            if (_glassBmp != null) { _glassBmp.Dispose(); _glassBmp = null; }
            Application.RemoveMessageFilter(this);
            base.OnFormClosed(e);
        }
    }

    // ================= 卡密系统 =================
    // 卡密格式：OKK-XXXXXXXX（8 位，字符表去掉易混的 I/O/0/1）
    // 校验：第 8 位 = 前 7 位 ASCII 和 的校验位；作者按此算法用 Ctrl+G 生成新卡密（自动写入 cfg）
    static class CardKey
    {
        public const string CH = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";   // 32 字符
        static Random _rnd = new Random();

        public static string Generate()
        {
            char[] c = new char[8];
            int s = 0;
            for (int i = 0; i < 7; i++) { c[i] = CH[_rnd.Next(CH.Length)]; s += (int)c[i]; }
            c[7] = CH[(s * 31 + 7) % CH.Length];
            return "OKK-" + new string(c);
        }

        public static bool Valid(string k)
        {
            if (string.IsNullOrEmpty(k)) return false;
            // 兼容带后缀的完整卡密：|YYYY-MM-DD 或 |NAME:xxx，只取 OKK-XXXXXXXX 本体校验
            string body = k.Trim().ToUpperInvariant();
            int bar = body.IndexOf('|');
            if (bar >= 0) body = body.Substring(0, bar);
            body = body.Replace("-", "").Replace(" ", "").Replace("_", "");
            if (body.Length != 11 || !body.StartsWith("OKK")) return false;
            string chk = body.Substring(3);
            if (chk.Length != 8) return false;
            int s = 0;
            for (int i = 0; i < 7; i++)
            {
                if (CH.IndexOf(chk[i]) < 0) return false;
                s += (int)chk[i];
            }
            return CH[(s * 31 + 7) % CH.Length] == chk[7];
        }

        // 从卡密文本提取到期日期 YYYY-MM-DD（无则返回空 = 永久卡）
        public static string ExtractExpire(string k)
        {
            if (string.IsNullOrEmpty(k)) return "";
            try
            {
                foreach (string p in k.Split('|'))
                {
                    string t = p.Trim();
                    if (t.Length == 10 && t[4] == '-' && t[7] == '-') return t;
                }
            }
            catch { }
            return "";
        }

        // 校验状态：-1 不存在/非法；0 永久有效；1 限时未过期；2 已过期
        // 列表项格式：OKK-XXXX 或 OKK-XXXX|YYYY-MM-DD 或 OKK-XXXX|NAME:名字 或组合
        static int ParseItem(string item, string want, out string name)
        {
            name = "";
            string[] parts = item.Trim().ToUpperInvariant().Split('|');
            if (parts.Length == 0 || parts[0] != want) return -1;
            string date = "";
            foreach (string p in parts)
            {
                if (p.StartsWith("NAME:")) name = p.Substring(5).Trim();
                else if (p.Length == 10 && p[4] == '-' && p[7] == '-') date = p;
            }
            if (date.Length > 0)
            {
                DateTime exp;
                if (DateTime.TryParseExact(date, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out exp))
                    return DateTime.Today > exp ? 2 : 1;
                return 0;
            }
            return 0;
        }

        // 本地列表校验
        public static int CheckLocal(string k, out string name)
        {
            name = "";
            if (!Valid(k)) return -1;
            string want = k.Trim().ToUpperInvariant();
            int bar = want.IndexOf('|');
            if (bar >= 0) want = want.Substring(0, bar);
            foreach (string item in AppConst.GetCfg("keys", "").Split(';'))
            {
                string t = item.Trim().ToUpperInvariant();
                if (t.Length == 0) continue;
                int st = ParseItem(t, want, out name);
                if (st >= 0) return st;
            }
            return -1;
        }

        // 联网校验（GitHub Gist raw_url，无需 token）
        // 返回 -2 = 服务器不可达（调用方回退本地）；其余同状态码
        public static int CheckServer(string k, out string name)
        {
            name = "";
            if (!Valid(k)) return -1;
            string raw = AppConst.GetCfg("gist_url", "").Trim();
            if (raw.Length == 0)
                raw = "https://gist.githubusercontent.com/mobaiseka/dbbfc2057bddc68a6af9e9f6638aca84/raw/okkg-keys.json"; // 内置默认卡密库（cfg 未配置时兜底）
            // 固定版本 raw_url（含 commit hash）转动态地址，保证云端更新后永远读到最新内容：
            // https://gist.githubusercontent.com/{owner}/{gist}/raw/{hash}/{file} → .../raw/{file}
            try
            {
                int idx = raw.IndexOf("/raw/", StringComparison.OrdinalIgnoreCase);
                if (idx > 0)
                {
                    string prefix = raw.Substring(0, idx);
                    string file = raw.Substring(raw.LastIndexOf('/') + 1);
                    if (file.Length > 0) raw = prefix + "/raw/" + file;
                }
            }
            catch { }
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(raw + (raw.Contains("?") ? "&" : "?") + "t=" + DateTimeOffset.UtcNow.ToUnixTimeSeconds());
                req.Method = "GET";
                req.Timeout = 10000;
                req.UserAgent = "OKK-Guardian/1.0";
                using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                {
                    if (resp.StatusCode != HttpStatusCode.OK) return -2;
                    using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                    {
                        string body = sr.ReadToEnd();
                        string want = k.Trim().ToUpperInvariant();
                        int bar = want.IndexOf('|');
                        if (bar >= 0) want = want.Substring(0, bar);
                        foreach (Match m in Regex.Matches(body, "OKK-[A-Z0-9]{8}(\\|[^\"\\\\]*)?", RegexOptions.IgnoreCase))
                        {
                            int st = ParseItem(m.Value, want, out name);
                            if (st >= 0) return st;
                        }
                    }
                }
            }
            catch { return -2; }
            return -1;
        }

        // 追加一张卡密到 cfg keys（作者用）
        public static string AddToCfg()
        {
            string k = Generate();
            string keys = AppConst.GetCfg("keys", "");
            if (keys.Trim().Length > 0) keys += ";";
            keys += k;
            AppConst.SetCfg("keys", keys);
            return k;
        }
    }

    // 激活窗口：玻璃风格、输入卡密（卡密由发放方用 ok-keygen 生成，程序内无生成入口）
    class ActivateForm : Form
    {
        private TextBox _tb;
        private Label _tip;
        private Button _btnOk;

        public ActivateForm()
        {
            Text = "激活 · 云电脑守护清理";
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(380, 252);
            BackColor = Color.FromArgb(238, 243, 250);
            Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Regular, GraphicsUnit.Point);

            Label title = new Label();
            title.Text = "云电脑守护清理";
            title.Font = new Font("Microsoft YaHei UI", 14f, FontStyle.Bold, GraphicsUnit.Point);
            title.ForeColor = Color.FromArgb(47, 62, 84);
            title.BackColor = BackColor;
            title.Bounds = new Rectangle(24, 22, 240, 30);
            Controls.Add(title);

            Label sub = new Label();
            sub.Text = "请输入卡密激活后使用";
            sub.Font = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Regular, GraphicsUnit.Point);
            sub.ForeColor = Color.FromArgb(120, 133, 150);
            sub.BackColor = BackColor;
            sub.Bounds = new Rectangle(24, 56, 240, 18);
            Controls.Add(sub);

            _tb = new TextBox();
            _tb.Bounds = new Rectangle(24, 92, 332, 32);
            _tb.Font = new Font("Consolas", 13f, FontStyle.Bold, GraphicsUnit.Point);
            _tb.BorderStyle = BorderStyle.FixedSingle;
            _tb.BackColor = Color.White;
            _tb.PasswordChar = '●';
            _tb.TextAlign = HorizontalAlignment.Center;
            _tb.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) TryActivate(); };
            Controls.Add(_tb);

            _btnOk = new Button();
            _btnOk.Text = "激 活";
            _btnOk.FlatStyle = FlatStyle.Flat;
            _btnOk.FlatAppearance.BorderSize = 0;
            _btnOk.BackColor = Color.FromArgb(56, 108, 208);
            _btnOk.ForeColor = Color.White;
            _btnOk.Font = new Font("Microsoft YaHei UI", 10f, FontStyle.Bold, GraphicsUnit.Point);
            _btnOk.Bounds = new Rectangle(24, 140, 332, 40);
            _btnOk.Cursor = Cursors.Hand;
            _btnOk.Click += (s, e) => TryActivate();
            Controls.Add(_btnOk);

            _tip = new Label();
            _tip.Text = "未激活时仅能运行启动动画，无法进入主界面。";
            _tip.Font = new Font("Microsoft YaHei UI", 8f, FontStyle.Regular, GraphicsUnit.Point);
            _tip.ForeColor = Color.FromArgb(150, 160, 175);
            _tip.BackColor = BackColor;
            _tip.Bounds = new Rectangle(24, 198, 340, 18);
            Controls.Add(_tip);

            _tb.Focus();
        }

        private void TryActivate()
        {
            string input = _tb.Text.Trim();
            string name = "";
            // 验证只认云端卡密库（服务器），不回退本地 keys，防止本地篡改绕过
            int st = CardKey.CheckServer(input, out name);
            if (st == -2)
            {
                _tip.ForeColor = Color.FromArgb(205, 62, 62);
                _tip.Text = "无法连接云端服务器，请检查网络后重试。";
                _tb.Focus();
                _tb.SelectAll();
            }
            else if (st == -1)
            {
                _tip.ForeColor = Color.FromArgb(205, 62, 62);
                _tip.Text = "卡密无效，请检查后重试。";
                _tb.Focus();
                _tb.SelectAll();
            }
            else if (st == 2)
            {
                _tip.ForeColor = Color.FromArgb(205, 62, 62);
                _tip.Text = "卡密已经到期，请联系发放方续期。";
                _tb.Focus();
                _tb.SelectAll();
            }
            else
            {
                AppConst.SetCfg("activated", "1");
                AppConst.SetCfg("activated_key", input.Trim());
                AppConst.SetCfg("owner", name);
                AppConst.SetCfg("activated_expire", CardKey.ExtractExpire(input));
                AppConst.Log("卡密激活成功" + (name.Length > 0 ? "（专属：" + name + "）" : ""));
                DialogResult = DialogResult.OK;
                Close();
            }
        }

        // 未输入有效卡密就关闭激活窗口 → 恢复被静默清理的平台进程（惩罚）
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (DialogResult != DialogResult.OK)
            {
                BootForm.RestoreBlockedProcesses();
                try
                {
                    _tip.ForeColor = Color.FromArgb(205, 62, 62);
                    _tip.Text = "未激活关闭：平台进程已恢复，请先激活再使用。";
                }
                catch { }
            }
            base.OnFormClosing(e);
        }
    }

    // ================= 程序入口 =================
    static class Program
    {
        [STAThread]
        static void Main()
        {
            // 反调试/篡改检测：发现即警告退出（放在一切窗口之前）
            BootForm.TamperGuard();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            bool skipBoot = false;
            foreach (string a in Environment.GetCommandLineArgs())
                if (a.Equals("/noboot", StringComparison.OrdinalIgnoreCase)) skipBoot = true;

            if (skipBoot)
            {
                Application.Run(new MainForm());
                return;
            }

            // 先播启动动画，动画窗体自动关闭后进入主窗体（顺序 Run，避免嵌套消息循环）
            BootForm boot = new BootForm();
            boot.StartAutoGuardKill();
            Application.Run(boot);

            // 卡密激活：未激活则弹出激活窗口，取消/关闭则退出
            if (AppConst.GetCfg("activated", "0") != "1")
            {
                using (ActivateForm af = new ActivateForm())
                {
                    if (af.ShowDialog() != DialogResult.OK) return;
                }
            }

            Application.Run(new MainForm());
        }
    }
}
