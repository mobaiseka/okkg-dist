// ================= 卡密生成器（作者专用，不随主程序分发） =================
// 功能：生成卡密 → 写入本地 ok-gui.cfg keys= → 同步到 GitHub Gist（公共卡密库）
// 主程序激活时联网校验 Gist 列表（无需 token），网络失败回退本地列表。
// 配置（ok-gui.cfg）：
//   github_token=ghp_xxx       作者 GitHub token（需 gist 权限），仅本工具使用
//   gist_id=xxx / gist_url=xxx 首次有 token 时自动创建并回填
// 用法：直接运行 ok-keygen.exe → 点「生成卡密」。
using System;
using System.Drawing;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

class CardKey
{
    public const string CH = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
    static Random _rnd = new Random();

    public static string Generate()
    {
        char[] c = new char[8];
        int s = 0;
        for (int i = 0; i < 7; i++) { c[i] = CH[_rnd.Next(CH.Length)]; s += (int)c[i]; }
        c[7] = CH[(s * 31 + 7) % CH.Length];
        return "OKK-" + new string(c);
    }

    public static bool Valid(string k)
    {
        if (string.IsNullOrEmpty(k)) return false;
        k = k.Trim().ToUpperInvariant().Replace("-", "").Replace(" ", "");
        if (k.Length != 11 || !k.StartsWith("OKK")) return false;
        string body = k.Substring(3);
        if (body.Length != 8) return false;
        int s = 0;
        for (int i = 0; i < 7; i++)
        {
            if (CH.IndexOf(body[i]) < 0) return false;
            s += (int)body[i];
        }
        return CH[(s * 31 + 7) % CH.Length] == body[7];
    }

    // 从任意文本中提取 OKK- 卡密（可带 |到期日期）
    public static System.Collections.Generic.List<string> Extract(string text)
    {
        System.Collections.Generic.List<string> list = new System.Collections.Generic.List<string>();
        foreach (Match m in Regex.Matches(text ?? "", "OKK-[A-Z0-9]{8}(\\|[0-9]{4}-[0-9]{2}-[0-9]{2})?"))
        {
            string k = m.Value;
            if (!list.Contains(k)) list.Add(k);
        }
        return list;
    }

    // 生成卡密；days>0 追加 |YYYY-MM-DD 到期；name 非空追加 |NAME:名字（专属卡）
    public static string Generate(int days, string name)
    {
        string k = Generate();
        if (days > 0) k += "|" + DateTime.Today.AddDays(days).ToString("yyyy-MM-dd");
        if (!string.IsNullOrEmpty(name))
        {
            string nm = name.Trim();
            if (nm.Length > 0) k += "|NAME:" + nm;
        }
        return k;
    }
}

class Cfg
{
    static string _path = null;
    public static string PathNow
    {
        get
        {
            if (_path != null) return _path;
            try
            {
                string p1 = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ok-gui.cfg");
                if (File.Exists(p1)) { _path = p1; return _path; }
                string p2 = @"C:\Users\Administrator\Downloads\ok-gui.cfg";
                if (File.Exists(p2)) { _path = p2; return _path; }
                _path = p1;
            }
            catch { _path = null; }
            return _path;
        }
    }
    public static string Get(string key, string def)
    {
        string p = PathNow;
        if (p == null || !File.Exists(p)) return def;
        try
        {
            foreach (string line in File.ReadAllLines(p, Encoding.UTF8))
            {
                if (line.StartsWith(key + "=")) return line.Substring(key.Length + 1).Trim();
            }
        }
        catch { }
        return def;
    }
    public static void Set(string key, string value)
    {
        string p = PathNow;
        if (p == null) return;
        try
        {
            string text = File.Exists(p) ? File.ReadAllText(p, Encoding.UTF8) : "";
            if (text.IndexOf(key + "=", StringComparison.Ordinal) >= 0)
            {
                int i0 = text.IndexOf(key + "=", StringComparison.Ordinal);
                int i1 = text.IndexOf("\r\n", i0, StringComparison.Ordinal);
                if (i1 < 0) i1 = text.Length;
                text = text.Substring(0, i0) + key + "=" + value + text.Substring(i1);
            }
            else
            {
                if (!text.EndsWith("\r\n") && text.Length > 0) text += "\r\n";
                text += key + "=" + value + "\r\n";
            }
            File.WriteAllText(p, text, new UTF8Encoding(false));
        }
        catch { }
    }
}

class GitHubStore
{
    const string GIST_FILE = "okkg-keys.json";

    // 有 token 时：确保 gist 存在并同步（合并本地新卡密 → PATCH 回 gist）；返回 (ok, msg)
    public static string Sync(string newKey)
    {
        string token = Cfg.Get("github_token", "").Trim();
        if (token.Length == 0) return "未配置 github_token，本次仅写入本地列表（离线模式）";

        try
        {
            string gistId = Cfg.Get("gist_id", "").Trim();
            string current = "";   // gist 内现有卡密 JSON 文本

            if (gistId.Length == 0)
            {
                // 首次：创建公开 gist
                string initJson = "[\"" + newKey + "\"]";
                string createBody = "{\"description\":\"OKK Guardian key store\",\"public\":true,\"files\":{\"" + GIST_FILE + "\":{\"content\":" + JsonString(initJson) + "}}}";
                int code1 = 0;
                string createResp = Request("https://api.github.com/gists", "POST", createBody, token, out code1);
                if (code1 != 201 && code1 != 200)
                    return "创建 Gist 失败（HTTP " + code1 + "），请检查 token 是否有 gist 权限";
                // 解析 id 和 raw_url
                Match mid = Regex.Match(createResp ?? "", "\"id\"\\s*:\\s*\"([a-f0-9]+)\"");
                Match mraw = Regex.Match(createResp ?? "", "\"raw_url\"\\s*:\\s*\"([^\"]+)\"");
                if (!mid.Success || !mraw.Success)
                    return "创建 Gist 成功但解析失败，请检查网络后重试";
                gistId = mid.Groups[1].Value;
                Cfg.Set("gist_id", gistId);
                Cfg.Set("gist_url", mraw.Groups[1].Value);
                return "已在 GitHub 创建卡密库（gist " + gistId + "），卡密已登记";
            }
            else
            {
                // 读取现有 gist 内容
                string rawUrl = Cfg.Get("gist_url", "");
                if (rawUrl.Length > 0)
                {
                    int codeR = 0;
                    string resp = Request(rawUrl, "GET", null, "", out codeR);
                    if (codeR == 200 && resp != null) current = resp;
                }
                var list = CardKey.Extract(current);
                if (!list.Contains(newKey)) list.Add(newKey);
                string json = "[" + string.Join(",", list.ConvertAll(k => "\"" + k + "\"")) + "]";
                string patchBody = "{\"files\":{\"" + GIST_FILE + "\":{\"content\":" + JsonString(json) + "}}}";
                int code2 = 0;
                string resp2 = Request("https://api.github.com/gists/" + gistId, "PATCH", patchBody, token, out code2);
                if (code2 != 200)
                    return "更新 Gist 失败（HTTP " + code2 + "）";
                return "已同步到 GitHub 卡密库（共 " + (list.Count) + " 张）";
            }
        }
        catch (Exception ex)
        {
            return "在线同步异常：" + ex.Message + "（本次已写入本地列表）";
        }
    }

    static string JsonString(string s)
    {
        return "\"" + s.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"";
    }

    static string Request(string url, string method, string body, string token, out int code)
    {
        code = 0;
        HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
        req.Method = method;
        req.Timeout = 12000;
        req.UserAgent = "OKK-KeyGen/1.0";
        req.Accept = "application/vnd.github+json";
        if (token.Length > 0) req.Headers["Authorization"] = "token " + token;
        if (body != null)
        {
            req.ContentType = "application/json";
            byte[] b = Encoding.UTF8.GetBytes(body);
            req.ContentLength = b.Length;
            using (Stream s = req.GetRequestStream()) s.Write(b, 0, b.Length);
        }
        try
        {
            using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
            {
                code = (int)resp.StatusCode;
                using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                    return sr.ReadToEnd();
            }
        }
        catch (WebException wex)
        {
            if (wex.Response != null)
            {
                code = (int)((HttpWebResponse)wex.Response).StatusCode;
                using (StreamReader sr = new StreamReader(wex.Response.GetResponseStream(), Encoding.UTF8))
                    return sr.ReadToEnd();
            }
            throw;
        }
    }
}

class KeyGenForm : Form
{
    private ListBox _list;
    private Label _tip;
    private Label _mode;
    private ComboBox _expiry;
    private TextBox _customDays;
    private TextBox _name;

    public KeyGenForm()
    {
        Text = "云电脑守护清理 · 卡密生成器";
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(420, 460);
        BackColor = Color.FromArgb(238, 243, 250);
        Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Regular, GraphicsUnit.Point);

        Label title = new Label();
        title.Text = "卡密生成器（作者专用）";
        title.Font = new Font("Microsoft YaHei UI", 13f, FontStyle.Bold, GraphicsUnit.Point);
        title.ForeColor = Color.FromArgb(47, 62, 84);
        title.BackColor = BackColor;
        title.Bounds = new Rectangle(20, 14, 260, 28);
        Controls.Add(title);

        _mode = new Label();
        _mode.Font = new Font("Microsoft YaHei UI", 8f, FontStyle.Regular, GraphicsUnit.Point);
        _mode.ForeColor = Color.FromArgb(52, 148, 96);
        _mode.BackColor = BackColor;
        _mode.Bounds = new Rectangle(20, 44, 380, 18);
        Controls.Add(_mode);

        // 有效期选择行
        Label el = new Label();
        el.Text = "有效期：";
        el.Font = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Regular, GraphicsUnit.Point);
        el.ForeColor = Color.FromArgb(90, 103, 120);
        el.BackColor = BackColor;
        el.Bounds = new Rectangle(20, 72, 60, 24);
        Controls.Add(el);

        _expiry = new ComboBox();
        _expiry.DropDownStyle = ComboBoxStyle.DropDownList;
        _expiry.Items.AddRange(new object[] { "永久", "1 天", "7 天", "30 天", "90 天", "自定义天数" });
        _expiry.SelectedIndex = 2;
        _expiry.Bounds = new Rectangle(80, 70, 130, 26);
        _expiry.Font = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Regular, GraphicsUnit.Point);
        _expiry.SelectedIndexChanged += (s, e) => _customDays.Visible = (_expiry.SelectedIndex == 5);
        Controls.Add(_expiry);

        _customDays = new TextBox();
        _customDays.Bounds = new Rectangle(220, 70, 90, 26);
        _customDays.Text = "60";
        _customDays.Visible = false;
        _customDays.Font = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Regular, GraphicsUnit.Point);
        Controls.Add(_customDays);

        Label dl = new Label();
        dl.Text = "天";
        dl.Font = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Regular, GraphicsUnit.Point);
        dl.ForeColor = Color.FromArgb(90, 103, 120);
        dl.BackColor = BackColor;
        dl.Bounds = new Rectangle(314, 72, 30, 24);
        dl.Visible = false;
        dl.Name = "dl";
        _customDays.VisibleChanged += (s, e) => dl.Visible = _customDays.Visible;
        Controls.Add(dl);

        // 专属名字行（可选，生成专属永久卡）
        Label nl = new Label();
        nl.Text = "专属名字：";
        nl.Font = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Regular, GraphicsUnit.Point);
        nl.ForeColor = Color.FromArgb(90, 103, 120);
        nl.BackColor = BackColor;
        nl.Bounds = new Rectangle(20, 106, 60, 24);
        Controls.Add(nl);

        _name = new TextBox();
        _name.Bounds = new Rectangle(80, 104, 220, 26);
        _name.Font = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Regular, GraphicsUnit.Point);
        _name.MaxLength = 20;
        Controls.Add(_name);

        Label hint = new Label();
        hint.Text = "留空 = 普通卡；填写 = 专属卡（登录显示此名字）";
        hint.Font = new Font("Microsoft YaHei UI", 7.5f, FontStyle.Regular, GraphicsUnit.Point);
        hint.ForeColor = Color.FromArgb(150, 160, 175);
        hint.BackColor = BackColor;
        hint.Bounds = new Rectangle(304, 106, 100, 40);
        Controls.Add(hint);

        Button btn = new Button();
        btn.Text = "生 成 卡 密";
        btn.FlatStyle = FlatStyle.Flat;
        btn.FlatAppearance.BorderSize = 0;
        btn.BackColor = Color.FromArgb(56, 108, 208);
        btn.ForeColor = Color.White;
        btn.Font = new Font("Microsoft YaHei UI", 10f, FontStyle.Bold, GraphicsUnit.Point);
        btn.Bounds = new Rectangle(20, 138, 380, 42);
        btn.Cursor = Cursors.Hand;
        btn.Click += (s, e) => Gen();
        Controls.Add(btn);

        Label l = new Label();
        l.Text = "已生成卡密（同步记录在下方）：";
        l.Font = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Regular, GraphicsUnit.Point);
        l.ForeColor = Color.FromArgb(120, 133, 150);
        l.BackColor = BackColor;
        l.Bounds = new Rectangle(20, 194, 200, 18);
        Controls.Add(l);

        Button btnCopy = new Button();
        btnCopy.Text = "复 制";
        btnCopy.FlatStyle = FlatStyle.Flat;
        btnCopy.FlatAppearance.BorderSize = 0;
        btnCopy.BackColor = Color.FromArgb(56, 108, 208);
        btnCopy.ForeColor = Color.White;
        btnCopy.Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Bold, GraphicsUnit.Point);
        btnCopy.Bounds = new Rectangle(310, 192, 90, 26);
        btnCopy.Cursor = Cursors.Hand;
        btnCopy.Click += (s, e) => CopyKey();
        Controls.Add(btnCopy);

        _list = new ListBox();
        _list.Bounds = new Rectangle(20, 218, 380, 150);
        _list.BorderStyle = BorderStyle.FixedSingle;
        _list.Font = new Font("Consolas", 10f, FontStyle.Regular, GraphicsUnit.Point);
        _list.BackColor = Color.White;
        Controls.Add(_list);

        _tip = new Label();
        _tip.Font = new Font("Microsoft YaHei UI", 8f, FontStyle.Regular, GraphicsUnit.Point);
        _tip.ForeColor = Color.FromArgb(150, 160, 175);
        _tip.BackColor = BackColor;
        _tip.Bounds = new Rectangle(20, 378, 380, 66);
        Controls.Add(_tip);

        RefreshMode();
    }

    private void RefreshMode()
    {
        string token = Cfg.Get("github_token", "").Trim();
        string gist = Cfg.Get("gist_id", "").Trim();
        if (token.Length == 0)
            _mode.Text = "当前：离线模式（未配置 github_token）。配置后自动同步 GitHub 卡密库。";
        else if (gist.Length == 0)
            _mode.Text = "当前：在线模式，首次生成将自动创建 GitHub 卡密库。";
        else
            _mode.Text = "当前：在线模式，卡密库 gist " + gist + "。";
    }

    private void CopyKey()
    {
        try
        {
            string k = "";
            if (_list.SelectedItem != null) k = _list.SelectedItem.ToString();
            else if (_list.Items.Count > 0) k = _list.Items[0].ToString();
            if (k.Length == 0)
            {
                _tip.ForeColor = Color.FromArgb(150, 160, 175);
                _tip.Text = "还没有卡密，请先点击「生成卡密」。";
                return;
            }
            Clipboard.SetText(k);
            _tip.ForeColor = Color.FromArgb(52, 148, 96);
            _tip.Text = "已复制到剪贴板：" + k + "\n（可 Ctrl+V 直接粘贴给使用者）";
        }
        catch { }
    }

    private void Gen()
    {
        // 计算有效期天数
        int days = 0;
        int idx = _expiry.SelectedIndex;
        if (idx == 1) days = 1;
        else if (idx == 2) days = 7;
        else if (idx == 3) days = 30;
        else if (idx == 4) days = 90;
        else if (idx == 5)
        {
            int.TryParse(_customDays.Text.Trim(), out days);
            if (days < 1) days = 1;
        }

        string k = CardKey.Generate(days, _name.Text);

        // 1. 写入本地列表
        string keys = Cfg.Get("keys", "");
        if (keys.Trim().Length > 0) keys += ";";
        keys += k;
        Cfg.Set("keys", keys);

        // 2. 在线同步（失败不影响本地）
        string syncMsg = GitHubStore.Sync(k);

        _list.Items.Insert(0, k);
        string expText = days > 0 ? "（" + DateTime.Today.AddDays(days).ToString("yyyy-MM-dd") + " 到期）" : "（永久）";
        string ownText = _name.Text.Trim().Length > 0 ? " · 专属：" + _name.Text.Trim() : "";
        _tip.ForeColor = Color.FromArgb(52, 148, 96);
        _tip.Text = "新卡密：" + k + " " + expText + ownText + "\n" + syncMsg;
        RefreshMode();
    }

    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new KeyGenForm());
    }
}
