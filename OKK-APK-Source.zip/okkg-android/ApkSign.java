import com.android.apksig.ApkSigner;
import com.android.apksig.ApkVerifier;

import java.io.File;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ApkSign {
    public static void main(String[] args) throws Exception {
        String input = args[0], output = args[1], ksPath = args[2], storePass = args[3], alias = args[4];
        boolean verifyOnly = args.length > 5 && args[5].equals("verify");

        if (verifyOnly) {
            ApkVerifier.Result r = new ApkVerifier.Builder(new File(input)).build().verify();
            System.out.println("v1=" + r.isVerifiedUsingV1Scheme() + " v2=" + r.isVerifiedUsingV2Scheme() + " v3=" + r.isVerifiedUsingV3Scheme() + " 整体=" + r.isVerified());
            System.exit(r.isVerified() ? 0 : 1);
        }

        KeyStore ks = KeyStore.getInstance("JKS");
        FileInputStream fis = new FileInputStream(ksPath);
        ks.load(fis, storePass.toCharArray());
        fis.close();
        PrivateKey pk = (PrivateKey) ks.getKey(alias, storePass.toCharArray());
        X509Certificate cert = (X509Certificate) ks.getCertificate(alias);
        List<X509Certificate> chain = new ArrayList<X509Certificate>();
        chain.add(cert);

        ApkSigner.SignerConfig sc = new ApkSigner.SignerConfig.Builder(alias, pk, chain).build();
        ApkSigner.Builder b = new ApkSigner.Builder(Collections.singletonList(sc));
        b.setInputApk(new File(input));
        b.setOutputApk(new File(output));
        b.setV1SigningEnabled(true);
        b.setV2SigningEnabled(true);
        b.build().sign();
        System.out.println("签名完成: " + output);
    }
}
