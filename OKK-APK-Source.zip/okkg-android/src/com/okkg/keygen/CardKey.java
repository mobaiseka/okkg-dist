package com.okkg.keygen;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

/** 卡密算法：与 PC 版 ok-keygen / ok-gui 完全一致 */
public class CardKey {
    private static final String CH = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
    private static final Random _rnd = new Random();

    public static String generate(int days, String name) {
        char[] c = new char[8];
        int s = 0;
        for (int i = 0; i < 7; i++) {
            c[i] = CH.charAt(_rnd.nextInt(CH.length()));
            s += (int) c[i];
        }
        c[7] = CH.charAt((s * 31 + 7) % CH.length());
        StringBuilder sb = new StringBuilder("OKK-").append(c);
        if (days > 0) {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, days);
            sb.append('|').append(new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime()));
        }
        if (name != null && name.trim().length() > 0) sb.append("|NAME:").append(name.trim());
        return sb.toString();
    }

    public static boolean valid(String k) {
        if (k == null) return false;
        k = k.trim().toUpperCase(Locale.US).replace("-", "");
        if (k.length() != 11 || !k.startsWith("OKK")) return false;
        String body = k.substring(3);
        int s = 0;
        for (int i = 0; i < 7; i++) {
            if (CH.indexOf(body.charAt(i)) < 0) return false;
            s += (int) body.charAt(i);
        }
        return CH.charAt((s * 31 + 7) % CH.length()) == body.charAt(7);
    }
}
