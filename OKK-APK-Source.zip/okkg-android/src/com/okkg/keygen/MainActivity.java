package com.okkg.keygen;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** 手机版卡密生成器：玻璃液态 + iOS 质感 UI（代码构建，无 XML 布局） */
public class MainActivity extends Activity {

    private static final int ACC = 0xFF2C6CDC;
    private static final int ACC2 = 0xFF1C4AA8;
    private static final int GLASS = 0x24FFFFFF;   // 玻璃底
    private static final int GLASS2 = 0x14FFFFFF;
    private static final int STROKE = 0x40FFFFFF;
    private static final int TXT = 0xFFFFFFFF;
    private static final int TXT2 = 0x99FFFFFF;

    private LinearLayout _listBox;
    private LinearLayout _cloudBox;
    private TextView _statusDot, _statusText;
    private int _daysMode = 7;          // 0=永久, 1,7,30,90, -1=自定义
    private int _customDays = 0;
    private final List<Button> _segBtns = new ArrayList<Button>();
    private EditText _nameEdit;
    private SharedPreferences _sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        _sp = GistStore.sp(this);
        // 预置现有云端卡密库（PC 主程序同库），手机生成卡密直接同步到同一 Gist
        if (_sp.getString("gist_id", "").length() == 0) {
            _sp.edit()
                    .putString("gist_id", "7a8fb419822493f30a359bea7fecfe85")
                    .putString("gist_url", "https://gist.githubusercontent.com/mobaiseka/dbbfc2057bddc68a6af9e9f6638aca84/raw/okkg-keys.json")
                    .commit();
        }
        setContentView(buildUi());
        refreshStatus();
        refreshList();
    }

    // ============ 工具 ============
    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable glassCard() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(GLASS);
        g.setCornerRadius(dp(22));
        g.setStroke(dp(1), STROKE);
        return g;
    }

    private GradientDrawable pillBg(boolean selected) {
        GradientDrawable g = new GradientDrawable();
        if (selected) {
            g.setColor(ACC);
            g.setCornerRadius(dp(18));
        } else {
            g.setColor(GLASS2);
            g.setCornerRadius(dp(18));
            g.setStroke(dp(1), 0x2EFFFFFF);
        }
        return g;
    }

    private Button segButton(String label, final int mode) {
        final Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(TXT);
        b.setPadding(dp(6), dp(7), dp(6), dp(7));
        b.setMinWidth(0);
        b.setGravity(Gravity.CENTER);
        b.setBackground(pillBg(mode == _daysMode));
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (mode == -1) askCustomDays();
                else {
                    _daysMode = mode;
                    refreshSeg();
                }
            }
        });
        _segBtns.add(b);
        return b;
    }

    private void refreshSeg() {
        for (Button b : _segBtns) b.setBackground(pillBg(b.getTag() != null && ((Integer) b.getTag()) == _daysMode));
    }

    private void askCustomDays() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setHint("天数（如 15）");
        et.setTextColor(TXT);
        new AlertDialog.Builder(this)
                .setTitle("自定义有效期")
                .setView(et)
                .setPositiveButton("确定", new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface d, int w) {
                        try {
                            int n = Integer.parseInt(et.getText().toString().trim());
                            if (n <= 0) { Toast.makeText(MainActivity.this, "天数需大于 0", Toast.LENGTH_SHORT).show(); return; }
                            _customDays = n;
                            _daysMode = -1;
                            refreshSeg();
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "请输入数字", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // ============ UI 构建 ============
    private View buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF0E1B2E, 0xFF16294A}));

        // 光斑（模拟 iOS 壁纸模糊辉光）
        FrameLayout.LayoutParams glow1 = new FrameLayout.LayoutParams(dp(300), dp(300), Gravity.TOP | Gravity.START);
        glow1.setMargins(-dp(80), -dp(40), 0, 0);
        GradientDrawable g1 = new GradientDrawable();
        g1.setShape(GradientDrawable.OVAL);
        g1.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        g1.setGradientRadius(dp(150));
        g1.setColors(new int[]{0x6633A6FF, 0x00000000});
        View v1 = new View(this);
        v1.setBackground(g1);
        root.addView(v1, glow1);

        FrameLayout.LayoutParams glow2 = new FrameLayout.LayoutParams(dp(260), dp(260), Gravity.BOTTOM | Gravity.END);
        glow2.setMargins(0, 0, -dp(60), -dp(60));
        GradientDrawable g2 = new GradientDrawable();
        g2.setShape(GradientDrawable.OVAL);
        g2.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        g2.setGradientRadius(dp(130));
        g2.setColors(new int[]{0x5534C759, 0x00000000});
        View v2 = new View(this);
        v2.setBackground(g2);
        root.addView(v2, glow2);

        // 内容
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(30), dp(22), dp(30));
        sv.addView(box);

        // 标题
        TextView title = new TextView(this);
        title.setText("卡密生成器");
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(TXT);
        box.addView(title);

        TextView sub = new TextView(this);
        sub.setText("OKK GUARDIAN · 作者专用");
        sub.setTextSize(12);
        sub.setTextColor(TXT2);
        sub.setPadding(0, dp(4), 0, 0);
        box.addView(sub);

        // 状态胶囊
        LinearLayout status = new LinearLayout(this);
        status.setOrientation(LinearLayout.HORIZONTAL);
        status.setGravity(Gravity.CENTER_VERTICAL);
        status.setPadding(dp(14), dp(7), dp(14), dp(7));
        GradientDrawable stBg = new GradientDrawable();
        stBg.setColor(GLASS2);
        stBg.setCornerRadius(dp(16));
        stBg.setStroke(dp(1), STROKE);
        status.setBackground(stBg);
        LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stLp.topMargin = dp(18);
        status.setLayoutParams(stLp);

        _statusDot = new TextView(this);
        _statusDot.setText("●");
        _statusDot.setTextSize(10);
        _statusDot.setPadding(0, 0, dp(7), 0);
        status.addView(_statusDot);

        _statusText = new TextView(this);
        _statusText.setTextSize(12);
        _statusText.setTextColor(TXT2);
        status.addView(_statusText);
        box.addView(status);

        // ===== 卡片：有效期 =====
        box.addView(glassCardWrap(buildSegCard(), "有效期", 0));

        // ===== 卡片：专属名字 =====
        box.addView(glassCardWrap(buildNameCard(), "专属名字", 14));

        // ===== 生成按钮 =====
        Button gen = new Button(this);
        gen.setText("生 成 卡 密");
        gen.setTextSize(16);
        gen.setTypeface(Typeface.DEFAULT_BOLD);
        gen.setTextColor(TXT);
        gen.setBackground(genBg());
        LinearLayout.LayoutParams genLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        genLp.topMargin = dp(20);
        gen.setLayoutParams(genLp);
        gen.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { doGenerate(); }
        });
        box.addView(gen);

        // ===== 卡密列表 =====
        TextView listTitle = new TextView(this);
        listTitle.setText("已生成卡密");
        listTitle.setTextSize(14);
        listTitle.setTypeface(Typeface.DEFAULT_BOLD);
        listTitle.setTextColor(TXT);
        LinearLayout.LayoutParams ltLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ltLp.topMargin = dp(24);
        listTitle.setLayoutParams(ltLp);
        box.addView(listTitle);

        _listBox = new LinearLayout(this);
        _listBox.setOrientation(LinearLayout.VERTICAL);
        box.addView(_listBox);

        // ===== 云端卡密库 =====
        TextView cloudTitle = new TextView(this);
        cloudTitle.setText("云端卡密库（服务器全部卡密）");
        cloudTitle.setTextSize(14);
        cloudTitle.setTypeface(Typeface.DEFAULT_BOLD);
        cloudTitle.setTextColor(TXT);
        LinearLayout.LayoutParams ctLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ctLp.topMargin = dp(26);
        cloudTitle.setLayoutParams(ctLp);
        box.addView(cloudTitle);

        Button refreshBtn = new Button(this);
        refreshBtn.setText("刷 新 云 端");
        refreshBtn.setTextSize(12);
        refreshBtn.setTypeface(Typeface.DEFAULT_BOLD);
        refreshBtn.setTextColor(TXT);
        refreshBtn.setBackground(genBg());
        LinearLayout.LayoutParams rbLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        rbLp.topMargin = dp(10);
        refreshBtn.setLayoutParams(rbLp);
        refreshBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { loadCloud(); }
        });
        box.addView(refreshBtn);

        _cloudBox = new LinearLayout(this);
        _cloudBox.setOrientation(LinearLayout.VERTICAL);
        box.addView(_cloudBox);

        // ===== GitHub 设置 =====
        Button setBtn = new Button(this);
        setBtn.setText("GitHub 服务器设置");
        setBtn.setTextSize(12);
        setBtn.setTextColor(TXT2);
        setBtn.setBackground(pillBg(false));
        LinearLayout.LayoutParams setLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38));
        setLp.topMargin = dp(18);
        setLp.gravity = Gravity.CENTER_HORIZONTAL;
        setBtn.setLayoutParams(setLp);
        setBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { openSettings(); }
        });
        box.addView(setBtn);

        root.addView(sv);
        return root;
    }

    private View glassCardWrap(View inner, String label, int topMargin) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(glassCard());
        card.setPadding(dp(16), dp(12), dp(16), dp(14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(topMargin);
        card.setLayoutParams(lp);

        TextView lab = new TextView(this);
        lab.setText(label);
        lab.setTextSize(12);
        lab.setTextColor(TXT2);
        card.addView(lab);

        if (inner.getParent() != null) ((ViewGroup) inner.getParent()).removeView(inner);
        card.addView(inner);
        return card;
    }

    private View buildSegCard() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(10);
        row.setLayoutParams(rp);

        int[] modes = new int[]{0, 7, 30, 90, -1};
        String[] labels = new String[]{"永久", "7天", "30天", "90天", "自定义"};
        for (int i = 0; i < modes.length; i++) {
            Button b = segButton(labels[i], modes[i]);
            b.setTag(modes[i]);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(34), 1f);
            bp.setMargins(dp(2), 0, dp(2), 0);
            row.addView(b, bp);
        }
        _daysMode = 7;
        return row;
    }

    private View buildNameCard() {
        _nameEdit = new EditText(this);
        _nameEdit.setSingleLine(true);
        _nameEdit.setTextSize(14);
        _nameEdit.setTextColor(TXT);
        _nameEdit.setHintTextColor(TXT2);
        _nameEdit.setHint("留空 = 普通卡；填写 = 专属卡（登录显示名字）");
        GradientDrawable g = new GradientDrawable();
        g.setColor(GLASS2);
        g.setCornerRadius(dp(16));
        g.setStroke(dp(1), 0x2EFFFFFF);
        _nameEdit.setBackground(g);
        _nameEdit.setPadding(dp(14), 0, dp(14), 0);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        ep.topMargin = dp(10);
        _nameEdit.setLayoutParams(ep);
        return _nameEdit;
    }

    private StateListDrawable genBg() {
        GradientDrawable normal = new GradientDrawable();
        normal.setCornerRadius(dp(26));
        normal.setColors(new int[]{ACC, ACC2});
        normal.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
        GradientDrawable pressed = new GradientDrawable();
        pressed.setCornerRadius(dp(26));
        pressed.setColor(0xFF1C4AA8);
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, pressed);
        s.addState(new int[]{}, normal);
        return s;
    }

    // ============ 逻辑 ============
    private void doGenerate() {
        int days = 0;
        if (_daysMode > 0) days = _daysMode;
        else if (_daysMode == -1) days = _customDays;
        String name = _nameEdit.getText().toString().trim();
        final String key = CardKey.generate(days, name);
        final String localKeys = _sp.getString("keys_local", "");
        _sp.edit().putString("keys_local", localKeys.length() == 0 ? key : localKeys + ";" + key).commit();
        addListRow(key, "生成中…", TXT2);

        final Context ctx = this;
        new Thread(new Runnable() {
            public void run() {
                final GistStore.Result r = GistStore.sync(ctx, key);
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (r.ok) {
                            addListRow(key, "已同步 Gist", 0xFF34C759);
                            _statusText.setText("Gist 在线 · " + r.msg);
                            _statusDot.setTextColor(0xFF34C759);
                        } else {
                            addListRow(key, r.msg, 0xFFE5A50A);
                        }
                        Toast.makeText(ctx, r.ok ? "卡密已生成并同步" : "卡密已生成（" + r.msg + "）", Toast.LENGTH_LONG).show();
                        refreshStatus();
                    }
                });
            }
        }).start();
    }

    private void addListRow(final String key, String state, int stateColor) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(10), dp(10), dp(10));
        GradientDrawable g = new GradientDrawable();
        g.setColor(GLASS2);
        g.setCornerRadius(dp(16));
        g.setStroke(dp(1), 0x22FFFFFF);
        row.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        row.setLayoutParams(lp);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        left.setLayoutParams(llp);

        TextView k = new TextView(this);
        k.setText(key);
        k.setTextSize(13);
        k.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        k.setTextColor(TXT);
        k.setMaxLines(1);
        k.setEllipsize(android.text.TextUtils.TruncateAt.END);
        left.addView(k);

        TextView s = new TextView(this);
        s.setText(state);
        s.setTextSize(11);
        s.setTextColor(stateColor);
        s.setPadding(0, dp(3), 0, 0);
        left.addView(s);

        row.addView(left);

        row.addView(smallBtn("复制", new View.OnClickListener() {
            public void onClick(View v) { copyKey(key); }
        }));
        row.addView(smallBtn("删", new View.OnClickListener() {
            public void onClick(View v) { confirmDelete(key); }
        }));

        _listBox.addView(row, 0);
    }

    private Button smallBtn(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(11);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(TXT);
        b.setBackground(pillBg(false));
        b.setPadding(dp(8), dp(4), dp(8), dp(4));
        b.setMinWidth(0);
        b.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(30));
        bp.setMargins(dp(5), 0, 0, 0);
        b.setLayoutParams(bp);
        b.setOnClickListener(l);
        return b;
    }

    private void copyKey(String key) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("okkg", key));
            Toast.makeText(this, "已复制：" + key, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "复制失败", Toast.LENGTH_SHORT).show();
        }
    }

    private void confirmDelete(final String key) {
        new AlertDialog.Builder(this)
                .setTitle("删除卡密")
                .setMessage("删除 " + key + "\n本地记录将移除；已配置云端则同步从 Gist 卡密库删除。")
                .setPositiveButton("删 除", new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface d, int w) {
                        deleteKey(key);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void deleteKey(final String key) {
        // 本地移除
        String s = _sp.getString("keys_local", "");
        StringBuilder sb = new StringBuilder();
        for (String it : s.split(";")) {
            String t = it.trim();
            if (t.length() > 0 && !t.equals(key)) {
                if (sb.length() > 0) sb.append(";");
                sb.append(t);
            }
        }
        _sp.edit().putString("keys_local", sb.toString()).commit();

        // 云端移除（异步）
        final Context ctx = this;
        new Thread(new Runnable() {
            public void run() {
                final GistStore.Result r = GistStore.remove(ctx, key);
                runOnUiThread(new Runnable() {
                    public void run() {
                        Toast.makeText(ctx, r.ok ? "已删除（云端已同步）" : "已删除本地（" + r.msg + "）", Toast.LENGTH_LONG).show();
                        refreshList();
                        loadCloud();
                    }
                });
            }
        }).start();
    }

    private void refreshStatus() {
        String token = GistStore.getToken(this);
        if (token.length() > 0) {
            _statusDot.setTextColor(0xFF34C759);
            _statusText.setText("Gist 在线 · 服务器已配置");
        } else {
            _statusDot.setTextColor(0xFF8E8E93);
            _statusText.setText("离线模式 · 点下方设置 token");
        }
    }

    private void loadCloud() {
        _cloudBox.removeAllViews();
        final Context ctx = this;
        new Thread(new Runnable() {
            public void run() {
                final java.util.List<String> cloud = new ArrayList<String>();
                final GistStore.Result r = GistStore.fetchCloud(ctx, cloud);
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (!r.ok) {
                            TextView t = new TextView(MainActivity.this);
                            t.setText("云端不可用：" + r.msg);
                            t.setTextSize(12);
                            t.setTextColor(0xFFE5A50A);
                            t.setPadding(dp(14), dp(10), dp(14), dp(10));
                            GradientDrawable g = new GradientDrawable();
                            g.setColor(GLASS2);
                            g.setCornerRadius(dp(14));
                            t.setBackground(g);
                            _cloudBox.addView(t);
                            Toast.makeText(ctx, r.msg, Toast.LENGTH_LONG).show();
                            return;
                        }
                        if (cloud.size() == 0) {
                            TextView t = new TextView(MainActivity.this);
                            t.setText("云端暂无卡密");
                            t.setTextSize(12);
                            t.setTextColor(TXT2);
                            t.setPadding(dp(14), dp(10), dp(14), dp(10));
                            _cloudBox.addView(t);
                            return;
                        }
                        for (String key : cloud) {
                            addCloudRow(key);
                        }
                        Toast.makeText(ctx, r.msg, Toast.LENGTH_LONG).show();
                    }
                });
            }
        }).start();
    }

    private void addCloudRow(final String key) {
        String state = cloudState(key);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(10), dp(10), dp(10));
        GradientDrawable g = new GradientDrawable();
        g.setColor(GLASS2);
        g.setCornerRadius(dp(16));
        g.setStroke(dp(1), 0x22FFFFFF);
        row.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        row.setLayoutParams(lp);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        left.setLayoutParams(llp);

        TextView k = new TextView(this);
        k.setText(key);
        k.setTextSize(12);
        k.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        k.setTextColor(TXT);
        k.setMaxLines(1);
        k.setEllipsize(android.text.TextUtils.TruncateAt.END);
        left.addView(k);

        TextView s = new TextView(this);
        s.setTextSize(11);
        s.setTextColor(0xFF8E8E93);
        s.setPadding(0, dp(3), 0, 0);
        java.util.Date exp = expireOf(key);
        if (exp != null) {
            s.setText(remainText(exp));
            row.setTag(exp);
            row.setTag(1, s);
            ensureTick();
        } else {
            s.setText(state);
        }
        left.addView(s);

        row.addView(left);
        row.addView(smallBtn("复制", new View.OnClickListener() {
            public void onClick(View v) { copyKey(key); }
        }));
        row.addView(smallBtn("删", new View.OnClickListener() {
            public void onClick(View v) { confirmDelete(key); }
        }));
        _cloudBox.addView(row);
    }

    private String cloudState(String key) {
        String[] parts = key.split("\\|");
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i < parts.length; i++) {
            String p = parts[i].trim();
            if (p.startsWith("NAME:")) sb.append("专属:").append(p.substring(5)).append(" · ");
            else if (p.length() == 10 && p.charAt(4) == '-' && p.charAt(7) == '-')
                sb.append(p).append(" 到期");
        }
        String r = sb.toString().trim();
        if (r.endsWith("·")) r = r.substring(0, r.length() - 1).trim();
        return r.length() == 0 ? "永久卡" : r;
    }

    private final android.os.Handler _tick = new android.os.Handler();
    private boolean _tickStarted = false;
    private final Runnable _tickRun = new Runnable() {
        public void run() {
            try {
                for (int i = 0; i < _cloudBox.getChildCount(); i++) {
                    View v = _cloudBox.getChildAt(i);
                    Object tag = v.getTag();
                    if (tag instanceof java.util.Date) {
                        TextView sv = (TextView) v.getTag(1);
                        if (sv != null) sv.setText(remainText((java.util.Date) tag));
                    }
                }
            } catch (Exception e) { }
            _tick.postDelayed(this, 1000);
        }
    };
    private void ensureTick() {
        if (!_tickStarted) { _tickStarted = true; _tick.postDelayed(_tickRun, 1000); }
    }
    private java.util.Date expireOf(String key) {
        try {
            String[] parts = key.split("\\|");
            for (String pp : parts) {
                pp = pp.trim();
                if (pp.length() == 10 && pp.charAt(4) == '-' && pp.charAt(7) == '-')
                    return new java.text.SimpleDateFormat("yyyy-MM-dd").parse(pp);
            }
        } catch (Exception e) { }
        return null;
    }
    private String remainText(java.util.Date exp) {
        long ms = exp.getTime() - System.currentTimeMillis();
        String head = ms >= 0 ? "剩余 " : "已过期 ";
        long t = Math.abs(ms) / 1000;
        long d = t / 86400; t %= 86400;
        long h = t / 3600; t %= 3600;
        long m = t / 60; long s = t % 60;
        StringBuilder b = new StringBuilder(head);
        if (d > 0) b.append(d).append("天 ");
        if (h > 0) b.append(h).append("小时 ");
        if (m > 0) b.append(m).append("分 ");
        b.append(s).append("秒");
        return b.toString();
    }

    private void refreshList() {
        _listBox.removeAllViews();
        String s = _sp.getString("keys_local", "");
        if (s.length() == 0) {
            TextView empty = new TextView(this);
            empty.setText("还没有生成过卡密");
            empty.setTextSize(13);
            empty.setTextColor(TXT2);
            empty.setPadding(dp(14), dp(14), dp(14), dp(14));
            GradientDrawable g = new GradientDrawable();
            g.setColor(GLASS2);
            g.setCornerRadius(dp(16));
            empty.setBackground(g);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = dp(8);
            empty.setLayoutParams(lp);
            _listBox.addView(empty);
            return;
        }
        String[] arr = s.split(";");
        for (int i = arr.length - 1; i >= 0; i--) {
            String v = arr[i].trim();
            if (v.length() > 0) addListRow(v, "本地已存", 0xFF8E8E93);
        }
    }

    private void openSettings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(GistStore.getToken(this));
        et.setHint("GitHub token（gist 权限）");
        et.setTextColor(TXT);
        box.addView(et);

        final EditText etId = new EditText(this);
        etId.setSingleLine(true);
        etId.setText(GistStore.getGistId(this));
        etId.setHint("Gist ID（留空=自动新建卡密库）");
        etId.setTextColor(TXT);
        LinearLayout.LayoutParams idLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        idLp.topMargin = dp(8);
        etId.setLayoutParams(idLp);
        box.addView(etId);

        final EditText etUrl = new EditText(this);
        etUrl.setSingleLine(true);
        etUrl.setText(GistStore.getGistUrl(this));
        etUrl.setHint("Gist raw URL（与 ID 配套）");
        etUrl.setTextColor(TXT);
        LinearLayout.LayoutParams urlLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        urlLp.topMargin = dp(8);
        etUrl.setLayoutParams(urlLp);
        box.addView(etUrl);

        new AlertDialog.Builder(this)
                .setTitle("GitHub 服务器设置")
                .setMessage("已预置你的云端卡密库（与 PC 主程序同库）。填 token 后生成卡密自动同步；想换库可改 Gist ID/URL。")
                .setView(box)
                .setPositiveButton("保存", new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface d, int w) {
                        GistStore.saveToken(MainActivity.this, et.getText().toString());
                        String id = etId.getText().toString().trim();
                        String url = etUrl.getText().toString().trim();
                        if (id.length() == 0) id = GistStore.getGistId(MainActivity.this);
                        if (url.length() == 0) url = GistStore.getGistUrl(MainActivity.this);
                        GistStore.saveGist(MainActivity.this, id, url);
                        refreshStatus();
                        Toast.makeText(MainActivity.this, "已保存，生成卡密时将自动同步", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }
}
