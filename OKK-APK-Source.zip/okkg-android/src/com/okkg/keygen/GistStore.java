package com.okkg.keygen;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** GitHub Gist 卡密库同步：token 配置后自动创建/更新公开 gist，主程序无需 token 只读校验 */
public class GistStore {
    private static final String GIST_FILE = "okkg-keys.json";

    public static class Result {
        public boolean ok;
        public String msg;
        public Result(boolean ok, String msg) { this.ok = ok; this.msg = msg; }
    }

    public static String getToken(Context ctx) {
        return sp(ctx).getString("github_token", "").trim();
    }

    public static String getGistId(Context ctx) {
        return sp(ctx).getString("gist_id", "").trim();
    }

    /** 优先从 gist_url 解析 gist_id（raw URL 内含真实 ID），解析不到再用存储值，防止 ID 存错/清空导致 404 */
    public static String resolveGistId(Context ctx) {
        String url = getGistUrl(ctx);
        if (url != null && url.length() > 0) {
            Matcher m = Pattern.compile("/([a-f0-9]{20,})/").matcher(url);
            if (m.find()) return m.group(1);
        }
        return getGistId(ctx);
    }

    public static String getGistUrl(Context ctx) {
        return sp(ctx).getString("gist_url", "").trim();
    }

    public static SharedPreferences sp(Context ctx) {
        return ctx.getSharedPreferences("okkg_cfg", Context.MODE_PRIVATE);
    }

    public static void saveToken(Context ctx, String token) {
        sp(ctx).edit().putString("github_token", token.trim()).commit();
    }

    public static void saveGist(Context ctx, String gistId, String gistUrl) {
        sp(ctx).edit()
                .putString("gist_id", gistId.trim())
                .putString("gist_url", gistUrl.trim())
                .commit();
    }

    /** 同步一张新卡密到 Gist；无 token 时仅本地（离线模式） */
    public static Result sync(Context ctx, String newKey) {
        String token = getToken(ctx);
        if (token.length() == 0)
            return new Result(false, "离线模式（未配置 token）");
        try {
            String gistId = resolveGistId(ctx);
            if (gistId.length() == 0) {
                // 创建公开 gist
                String initJson = "[\"" + newKey + "\"]";
                String body = "{\"description\":\"OKK Guardian key store\",\"public\":true,\"files\":{\"" + GIST_FILE + "\":{\"content\":" + jsonString(initJson) + "}}}";
                int[] code = new int[1];
                String resp = request("https://api.github.com/gists", "POST", body, token, code);
                if (code[0] != 201 && code[0] != 200)
                    return new Result(false, "创建 Gist 失败（HTTP " + code[0] + "）");
                Matcher mid = Pattern.compile("\"id\"\\s*:\\s*\"([a-f0-9]+)\"").matcher(resp == null ? "" : resp);
                Matcher mraw = Pattern.compile("\"raw_url\"\\s*:\\s*\"([^\"]+)\"").matcher(resp == null ? "" : resp);
                if (!mid.find() || !mraw.find())
                    return new Result(false, "创建成功但解析失败");
                sp(ctx).edit().putString("gist_id", mid.group(1)).putString("gist_url", mraw.group(1)).commit();
                return new Result(true, "已创建 Gist 卡密库，卡密已登记");
            } else {
                String current = "";
                String rawUrl = getGistUrl(ctx);
                if (rawUrl.length() > 0) {
                    int[] codeR = new int[1];
                    String resp = request(rawUrl, "GET", null, "", codeR);
                    if (codeR[0] == 200 && resp != null) current = resp;
                }
                List<String> list = extract(current);
                if (!list.contains(newKey)) list.add(newKey);
                StringBuilder sb = new StringBuilder("[");
                for (int i = 0; i < list.size(); i++) {
                    if (i > 0) sb.append(",");
                    sb.append("\"").append(list.get(i)).append("\"");
                }
                sb.append("]");
                String patchBody = "{\"files\":{\"" + GIST_FILE + "\":{\"content\":" + jsonString(sb.toString()) + "}}}";
                int[] code2 = new int[1];
                request("https://api.github.com/gists/" + gistId, "PATCH", patchBody, token, code2);
                if (code2[0] != 200)
                    return new Result(false, "更新 Gist 失败（HTTP " + code2[0] + "）");
                return new Result(true, "已同步到 Gist 卡密库（共 " + list.size() + " 张）");
            }
        } catch (Exception e) {
            return new Result(false, "网络异常: " + e.getMessage());
        }
    }

    /** 拉取云端卡密库全部卡密（带后缀时间/名字）；未配置云端返回 false */
    public static Result fetchCloud(Context ctx, List<String> out) {
        String rawUrl = getGistUrl(ctx);
        if (rawUrl.length() == 0)
            return new Result(false, "云端未配置");
        try {
            int[] code = new int[1];
            String resp = request(rawUrl, "GET", null, "", code);
            if (code[0] != 200 || resp == null)
                return new Result(false, "拉取失败（HTTP " + code[0] + "）");
            out.clear();
            out.addAll(extract(resp));
            return new Result(true, "云端共 " + out.size() + " 张");
        } catch (Exception e) {
            return new Result(false, "网络异常: " + e.getMessage());
        }
    }

    /** 从云端卡密库（Gist）移除一张卡密；未配置云端时仅提示 */
    public static Result remove(Context ctx, String key) {
        String token = getToken(ctx);
        String gistId = resolveGistId(ctx);
        String rawUrl = getGistUrl(ctx);
        if (token.length() == 0 || gistId.length() == 0)
            return new Result(false, "云端未配置（仅本地删除）");
        try {
            String current = "";
            if (rawUrl.length() > 0) {
                int[] codeR = new int[1];
                String resp = request(rawUrl, "GET", null, "", codeR);
                if (codeR[0] == 200 && resp != null) current = resp;
            }
            List<String> list = extract(current);
            list.remove(key);
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < list.size(); i++) {
                if (i > 0) sb.append(",");
                sb.append("\"").append(list.get(i)).append("\"");
            }
            sb.append("]");
            String patchBody = "{\"files\":{\"" + GIST_FILE + "\":{\"content\":" + jsonString(sb.toString()) + "}}}";
            int[] code2 = new int[1];
            request("https://api.github.com/gists/" + gistId, "PATCH", patchBody, token, code2);
            if (code2[0] != 200)
                return new Result(false, "云端删除失败（HTTP " + code2[0] + "）");
            return new Result(true, "已从云端卡密库移除");
        } catch (Exception e) {
            return new Result(false, "网络异常: " + e.getMessage());
        }
    }

    /** 从 gist 文本提取全部卡密 */
    public static List<String> extract(String text) {
        List<String> out = new ArrayList<String>();
        if (text == null) return out;
        Matcher m = Pattern.compile("OKK-[A-Z0-9]{8}(\\|[^\"\\\\]*)?", Pattern.CASE_INSENSITIVE).matcher(text);
        while (m.find()) {
            String v = m.group().trim();
            if (!out.contains(v)) out.add(v);
        }
        return out;
    }

    private static String jsonString(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\\') sb.append('\\').append(c);
            else if (c == '\n') sb.append("\\n");
            else sb.append(c);
        }
        return sb.append("\"").toString();
    }

    private static String request(String url, String method, String body, String token, int[] code) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod(method);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        conn.setRequestProperty("User-Agent", "OKK-Guardian/1.0 (Android)");
        conn.setRequestProperty("Accept", "application/vnd.github+json");
        if (token.length() > 0) conn.setRequestProperty("Authorization", "token " + token);
        if (body != null) {
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            byte[] data = body.getBytes("UTF-8");
            OutputStream os = conn.getOutputStream();
            os.write(data);
            os.flush();
            os.close();
        }
        code[0] = conn.getResponseCode();
        if (code[0] == 200 || code[0] == 201) {
            InputStream is = conn.getInputStream();
            BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            r.close();
            return sb.toString();
        }
        return null;
    }
}
